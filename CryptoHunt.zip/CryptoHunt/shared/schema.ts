import { sql } from "drizzle-orm";
import { pgTable, text, varchar, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const cryptoOperations = pgTable("crypto_operations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  operationType: text("operation_type").notNull(),
  inputData: jsonb("input_data").notNull(),
  result: jsonb("result"),
  status: text("status").notNull().default("pending"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertCryptoOperationSchema = createInsertSchema(cryptoOperations).pick({
  operationType: true,
  inputData: true,
  result: true,
  status: true,
});

export type InsertCryptoOperation = z.infer<typeof insertCryptoOperationSchema>;
export type CryptoOperation = typeof cryptoOperations.$inferSelect;

// Validation schemas for crypto operations
export const publicKeySchema = z.object({
  publicKey: z.string().min(1, "Public key is required"),
});

export const signatureVerificationSchema = z.object({
  messageHash: z.string().min(1, "Message hash is required"),
  rValue: z.string().min(1, "R value is required"),
  sValue: z.string().min(1, "S value is required"),
  publicKey: z.string().min(1, "Public key is required"),
});

export const keyRecoverySchema = z.object({
  rangeBegin: z.string().min(1, "Range begin is required"),
  rangeEnd: z.string().min(1, "Range end is required"),
  publicKey: z.string().min(1, "Public key is required"),
  bitLength: z.number().min(1, "Bit length must be positive"),
});

export const pointOperationSchema = z.object({
  operation: z.enum(["add", "double", "multiply", "divide", "validate"]),
  point1X: z.string().optional(),
  point1Y: z.string().optional(),
  point2X: z.string().optional(),
  point2Y: z.string().optional(),
  scalar: z.string().optional(),
});

export const addressGenerationSchema = z.object({
  publicKey: z.string().min(1, "Public key is required"),
  addressType: z.enum(["legacy", "segwit", "bech32"]).default("legacy"),
});

export const puzzleSolverSchema = z.object({
  startRange: z.string().min(1, "Start range is required"),
  endRange: z.string().min(1, "End range is required"),
  targetAddress: z.string().min(1, "Target address is required"),
  searchMode: z.enum(["sequential", "random", "hybrid"]).default("sequential"),
  bitLength: z.number().min(1).max(256),
  maxIterations: z.number().optional(),
});

export const bsgsSchema = z.object({
  targetPublicKey: z.string().min(1, "Target public key is required"),
  startRange: z.string().min(1, "Start range is required"),
  endRange: z.string().min(1, "End range is required"),
  babySteps: z.number().min(1000).max(10000000).default(100000),
});

export type PublicKeyInput = z.infer<typeof publicKeySchema>;
export type SignatureVerificationInput = z.infer<typeof signatureVerificationSchema>;
export type KeyRecoveryInput = z.infer<typeof keyRecoverySchema>;
export type PointOperationInput = z.infer<typeof pointOperationSchema>;
export type AddressGenerationInput = z.infer<typeof addressGenerationSchema>;
export type PuzzleSolverInput = z.infer<typeof puzzleSolverSchema>;
export type BsgsInput = z.infer<typeof bsgsSchema>;
