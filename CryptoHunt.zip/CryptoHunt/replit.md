# Secp256k1 Crypto Toolkit

## Overview

This is a comprehensive cryptographic toolkit application focused on the secp256k1 elliptic curve, commonly used in Bitcoin and other cryptocurrencies. The application provides a web-based interface for performing various cryptographic operations including public key manipulation, signature verification, private key recovery, and elliptic curve point operations.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Full-Stack Architecture
The application follows a modern full-stack architecture with clear separation of concerns:

- **Frontend**: React-based single-page application with TypeScript
- **Backend**: Express.js REST API server with TypeScript
- **Database**: PostgreSQL with Drizzle ORM (configured but using in-memory storage currently)
- **Build System**: Vite for frontend bundling and development
- **Styling**: Tailwind CSS with shadcn/ui component library

### Monorepo Structure
The codebase is organized as a monorepo with three main directories:
- `client/` - React frontend application
- `server/` - Express.js backend API
- `shared/` - Shared TypeScript types and schemas

## Key Components

### Frontend (Client)
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query for server state management
- **UI Library**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom crypto-themed color palette
- **Form Handling**: React Hook Form with Zod validation

### Backend (Server)
- **Framework**: Express.js with TypeScript
- **API Design**: RESTful endpoints for cryptographic operations
- **Validation**: Zod schemas for input validation
- **Storage**: In-memory storage (MemStorage class) with interface for future database integration
- **Development**: Hot module replacement via Vite integration

### Cryptographic Engine
- **Custom Implementation**: Pure TypeScript implementation of secp256k1 curve operations
- **Operations Supported**:
  - Public key compression/decompression
  - ECDSA signature verification
  - Private key recovery (brute force within ranges)
  - Point arithmetic (addition, doubling, multiplication, division)
  - Curve validation
  - Bitcoin address generation (Legacy, SegWit, Bech32)
  - Bitcoin puzzle solving with range-based brute force
  - Baby-Step Giant-Step (BSGS) algorithm for discrete logarithm
  - Multi-threading support for key generation
  - Performance monitoring and progress tracking

### Database Schema
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Schema**: Single table for crypto operations tracking
- **Migration**: Drizzle Kit for schema management

## Data Flow

### Frontend to Backend
1. User inputs are validated using Zod schemas on the frontend
2. TanStack Query mutations send HTTP requests to Express API endpoints
3. Backend validates inputs again using shared Zod schemas
4. Cryptographic operations are performed using custom secp256k1 implementation
5. Results are returned as JSON responses
6. Frontend displays results and provides copy-to-clipboard functionality

### State Management
- **Server State**: TanStack Query handles API communication, caching, and error states
- **Client State**: React useState for form inputs and UI state
- **Persistent State**: Operations are stored in memory (configurable for database storage)

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL database connectivity (future use)
- **drizzle-orm**: Type-safe ORM for database operations
- **@tanstack/react-query**: Server state management
- **@radix-ui/***: Headless UI component primitives
- **wouter**: Lightweight React router
- **zod**: TypeScript-first schema validation

### Development Dependencies
- **vite**: Build tool and dev server
- **typescript**: Type checking and compilation
- **tailwindcss**: Utility-first CSS framework
- **@replit/vite-plugin-***: Replit-specific development tools

### Styling Dependencies
- **tailwindcss**: Core styling framework
- **class-variance-authority**: Component variant management
- **clsx**: Conditional class name utility
- **tailwind-merge**: Tailwind class conflict resolution

## Deployment Strategy

### Development Environment
- **Dev Server**: Vite development server with HMR for frontend
- **API Server**: Express server with TypeScript compilation via tsx
- **Database**: PostgreSQL (configured via Drizzle, currently using in-memory storage)

### Production Build
- **Frontend**: Vite builds optimized static assets to `dist/public`
- **Backend**: esbuild bundles server code for Node.js execution
- **Deployment**: Single server deployment serving both API and static files

### Environment Configuration
- **Database URL**: Configured via `DATABASE_URL` environment variable
- **Development Mode**: Detected via `NODE_ENV` variable
- **Replit Integration**: Special handling for Replit environment features

### Security Considerations
- **Educational Purpose**: Application includes warnings about security implications
- **Input Validation**: Multi-layer validation using Zod schemas
- **Error Handling**: Structured error responses without sensitive information leakage
- **CORS**: Configured for development environment needs

The architecture is designed to be educational while maintaining production-ready code quality and security practices. The modular design allows for easy extension of cryptographic operations and potential migration to full database persistence.