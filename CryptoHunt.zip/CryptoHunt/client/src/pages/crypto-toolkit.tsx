import { useState } from "react";
import { NavigationSidebar } from "@/components/crypto/navigation-sidebar";
import { PublicKeyOperations } from "@/components/crypto/public-key-operations";
import { SignatureVerification } from "@/components/crypto/signature-verification";
import { KeyRecovery } from "@/components/crypto/key-recovery";
import { PointOperations } from "@/components/crypto/point-operations";
import { AddressGenerator } from "@/components/crypto/address-generator";
import { PuzzleSolver } from "@/components/crypto/puzzle-solver";
import { BsgsAlgorithm } from "@/components/crypto/bsgs-algorithm";
import { SecurityWarningModal } from "@/components/crypto/security-warning-modal";
import { Key, AlertTriangle, Shield, Search, Calculator, MapPin, Puzzle, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function CryptoToolkit() {
  const [activeSection, setActiveSection] = useState("pubkey");
  const [showSecurityModal, setShowSecurityModal] = useState(false);

  return (
    <div className="bg-slate-50 min-h-screen">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="bg-crypto-blue p-2 rounded-lg">
                <Key className="text-white" size={20} />
              </div>
              <div>
                <h1 className="text-xl font-semibold text-slate-900">Secp256k1 Toolkit</h1>
                <p className="text-sm text-slate-600">Elliptic Curve Cryptography Operations</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowSecurityModal(true)}
                className="text-slate-600 hover:text-slate-900"
              >
                <AlertTriangle size={16} className="mr-2" />
                Help
              </Button>
              <div className="bg-amber-100 text-amber-800 px-3 py-1 rounded-full text-xs font-medium">
                <AlertTriangle size={12} className="inline mr-1" />
                Security Tool
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar Navigation */}
          <NavigationSidebar 
            activeSection={activeSection} 
            onSectionChange={setActiveSection} 
          />

          {/* Main Content */}
          <div className="lg:col-span-3">
            {activeSection === "pubkey" && <PublicKeyOperations />}
            {activeSection === "signature" && <SignatureVerification />}
            {activeSection === "recovery" && <KeyRecovery />}
            {activeSection === "operations" && <PointOperations />}
            {activeSection === "address" && <AddressGenerator />}
            {activeSection === "puzzle" && <PuzzleSolver />}
            {activeSection === "bsgs" && <BsgsAlgorithm />}
          </div>
        </div>
      </div>

      <SecurityWarningModal 
        open={showSecurityModal} 
        onOpenChange={setShowSecurityModal} 
      />
    </div>
  );
}
