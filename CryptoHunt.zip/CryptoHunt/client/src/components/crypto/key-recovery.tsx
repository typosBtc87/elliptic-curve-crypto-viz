import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Play, AlertTriangle, Info, Copy } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface RecoveryResult {
  kangarooPrivKey?: string;
  realPrivKey?: string;
  shiftedPub?: string;
  progress: number;
  status: string;
}

export function KeyRecovery() {
  const [rangeBegin, setRangeBegin] = useState("0x659756abf6c17ca70e0000000000000000000140be6ddd93e441f8d4b4a85653b20b4cdcc5c748207a0daa16191d07a425d8080c276f9412472e0429e61bc355");
  const [rangeEnd, setRangeEnd] = useState("0x659756abf6c17ca70fffffffffffffffffffff40be6ddd93e441f8d4b4a85653b20b4cdcc5c748207a0daa16191d07a425d8080c276f9412472e0429e61bc355");
  const [publicKey, setPublicKey] = useState("03a61fc84b6429f07fc0edf25265ef7a0ced3cd9a0edea85e9f58b50b5d73f66e7");
  const [bitLength, setBitLength] = useState(361);
  const [result, setResult] = useState<RecoveryResult | null>(null);
  const { toast } = useToast();

  const recoveryMutation = useMutation({
    mutationFn: async (data: { rangeBegin: string; rangeEnd: string; publicKey: string; bitLength: number }) => {
      const response = await apiRequest("POST", "/api/crypto/recover-key", data);
      return response.json();
    },
    onSuccess: (data) => {
      setResult(data);
      toast({
        title: "Recovery Complete",
        description: "Private key recovery process completed successfully.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Recovery Failed",
        description: error.message || "Unable to recover private key",
        variant: "destructive",
      });
    },
  });

  const copyToClipboard = async (text: string, label: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast({
        title: "Copied!",
        description: `${label} copied to clipboard`,
      });
    } catch (error) {
      toast({
        title: "Copy Failed",
        description: "Unable to copy to clipboard",
        variant: "destructive",
      });
    }
  };

  const handleStartRecovery = () => {
    if (!rangeBegin.trim() || !rangeEnd.trim() || !publicKey.trim()) {
      toast({
        title: "Input Required",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }

    recoveryMutation.mutate({
      rangeBegin: rangeBegin.trim(),
      rangeEnd: rangeEnd.trim(),
      publicKey: publicKey.trim(),
      bitLength,
    });
  };

  return (
    <section className="bg-white rounded-xl border border-slate-200 p-6 mb-8">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-xl font-semibold text-slate-900">Private Key Recovery</h2>
          <p className="text-sm text-slate-600 mt-1">Derive private keys from curve operations and range analysis</p>
        </div>
        <div className="flex items-center space-x-2">
          <Badge variant="destructive" className="bg-red-100 text-red-700">
            <AlertTriangle size={12} className="mr-1" />
            Advanced
          </Badge>
          <Button variant="ghost" size="sm" className="text-slate-400 hover:text-slate-600">
            <Info size={16} />
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Range Configuration */}
        <div>
          <h3 className="text-sm font-medium text-slate-700 mb-3">Search Range</h3>
          <div className="space-y-3">
            <div>
              <Label className="text-xs font-medium text-slate-600 mb-1">Range Begin</Label>
              <Input
                value={rangeBegin}
                onChange={(e) => setRangeBegin(e.target.value)}
                className="font-mono text-xs"
              />
            </div>
            <div>
              <Label className="text-xs font-medium text-slate-600 mb-1">Range End</Label>
              <Input
                value={rangeEnd}
                onChange={(e) => setRangeEnd(e.target.value)}
                className="font-mono text-xs"
              />
            </div>
            <div>
              <Label className="text-xs font-medium text-slate-600 mb-1">Bit Length</Label>
              <Input
                type="number"
                value={bitLength}
                onChange={(e) => setBitLength(parseInt(e.target.value) || 0)}
                className="text-sm"
              />
            </div>
          </div>
        </div>

        {/* Target Public Key */}
        <div>
          <h3 className="text-sm font-medium text-slate-700 mb-3">Target Public Key</h3>
          <div className="space-y-3">
            <div>
              <Label className="text-xs font-medium text-slate-600 mb-1">Compressed Public Key</Label>
              <Textarea
                value={publicKey}
                onChange={(e) => setPublicKey(e.target.value)}
                className="font-mono text-xs resize-none"
                rows={3}
              />
            </div>
            
            {/* Range Shift Results */}
            {result?.shiftedPub && (
              <Card className="bg-blue-50 border-blue-200">
                <CardContent className="p-3">
                  <div className="text-xs font-medium text-blue-900 mb-2">Shifted Public Key</div>
                  <code className="text-xs font-mono text-blue-800 break-all">
                    {result.shiftedPub}
                  </code>
                </CardContent>
              </Card>
            )}
          </div>
        </div>

        {/* Recovery Process */}
        <div>
          <h3 className="text-sm font-medium text-slate-700 mb-3">Recovery Process</h3>
          <div className="space-y-3">
            <Button
              onClick={handleStartRecovery}
              disabled={recoveryMutation.isPending}
              className="w-full bg-crypto-blue hover:bg-blue-700 text-sm"
            >
              <Play size={16} className="mr-2" />
              {recoveryMutation.isPending ? "Processing..." : "Start Recovery"}
            </Button>
            
            {/* Progress Display */}
            <Card>
              <CardContent className="p-3">
                <div className="flex items-center justify-between text-xs mb-2">
                  <span className="text-slate-600">Progress</span>
                  <span className="text-slate-900 font-medium">
                    {result?.progress ?? 0}%
                  </span>
                </div>
                <Progress value={result?.progress ?? 0} className="h-2" />
              </CardContent>
            </Card>

            {/* Recovery Results */}
            {result && (
              <div className="space-y-2">
                {result.kangarooPrivKey && (
                  <Card>
                    <CardContent className="p-2">
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-slate-600">Kangaroo Private Key:</span>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => copyToClipboard(result.kangarooPrivKey!, "Kangaroo private key")}
                          className="p-0 h-auto"
                        >
                          <Copy size={12} />
                        </Button>
                      </div>
                      <code className="font-mono text-xs text-slate-900 break-all">
                        0x{result.kangarooPrivKey}
                      </code>
                    </CardContent>
                  </Card>
                )}
                {result.realPrivKey && (
                  <Card className="bg-emerald-50 border-emerald-200">
                    <CardContent className="p-2">
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-emerald-700">Recovered Private Key:</span>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => copyToClipboard(result.realPrivKey!, "Recovered private key")}
                          className="p-0 h-auto"
                        >
                          <Copy size={12} />
                        </Button>
                      </div>
                      <code className="font-mono text-xs text-emerald-900 break-all">
                        0x{result.realPrivKey}
                      </code>
                    </CardContent>
                  </Card>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
