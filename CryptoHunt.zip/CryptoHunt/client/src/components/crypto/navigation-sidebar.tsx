import { LockOpen, FileSignature, Search, Calculator, MapPin, Puzzle, Zap } from "lucide-react";

interface NavigationSidebarProps {
  activeSection: string;
  onSectionChange: (section: string) => void;
}

export function NavigationSidebar({ activeSection, onSectionChange }: NavigationSidebarProps) {
  const menuItems = [
    { id: "pubkey", label: "Public Key Tools", icon: LockOpen },
    { id: "signature", label: "Signature Verification", icon: FileSignature },
    { id: "recovery", label: "Key Recovery", icon: Search },
    { id: "operations", label: "Point Operations", icon: Calculator },
    { id: "address", label: "Address Generator", icon: MapPin },
    { id: "puzzle", label: "Bitcoin Puzzles", icon: Puzzle },
    { id: "bsgs", label: "BSGS Algorithm", icon: Zap },
  ];

  return (
    <div className="lg:col-span-1">
      <nav className="bg-white rounded-xl border border-slate-200 p-6 sticky top-24">
        <h2 className="text-lg font-semibold text-slate-900 mb-4">Operations</h2>
        <ul className="space-y-2">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeSection === item.id;
            
            return (
              <li key={item.id}>
                <button
                  onClick={() => onSectionChange(item.id)}
                  className={`flex items-center space-x-3 px-3 py-2 text-sm font-medium rounded-lg w-full text-left transition-colors ${
                    isActive
                      ? "text-crypto-blue bg-blue-50"
                      : "text-slate-600 hover:text-slate-900 hover:bg-slate-50"
                  }`}
                >
                  <Icon size={16} />
                  <span>{item.label}</span>
                </button>
              </li>
            );
          })}
        </ul>
        
        {/* Quick Stats */}
        <div className="mt-8 pt-6 border-t border-slate-200">
          <h3 className="text-sm font-medium text-slate-900 mb-3">Curve Parameters</h3>
          <div className="space-y-2 text-xs">
            <div className="flex justify-between">
              <span className="text-slate-600">Field Size (p):</span>
              <span className="font-mono text-slate-900">256-bit</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-600">Order (n):</span>
              <span className="font-mono text-slate-900">256-bit</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-600">Cofactor:</span>
              <span className="font-mono text-slate-900">1</span>
            </div>
          </div>
        </div>
      </nav>
    </div>
  );
}
