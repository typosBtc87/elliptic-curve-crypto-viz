import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { AlertTriangle } from "lucide-react";

interface SecurityWarningModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function SecurityWarningModal({ open, onOpenChange }: SecurityWarningModalProps) {
  const handleUnderstand = () => {
    onOpenChange(false);
  };

  const handleCancel = () => {
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <div className="flex items-center space-x-3 mb-2">
            <div className="bg-red-100 p-2 rounded-lg">
              <AlertTriangle className="text-red-600" size={20} />
            </div>
            <DialogTitle className="text-lg font-semibold text-slate-900">
              Security Warning
            </DialogTitle>
          </div>
          <DialogDescription className="text-sm text-slate-600">
            This tool performs cryptographic operations that should only be used for educational purposes 
            or authorized security research. Never use this tool with real private keys or on production systems.
          </DialogDescription>
        </DialogHeader>
        
        <div className="mt-4 p-4 bg-amber-50 border border-amber-200 rounded-lg">
          <h4 className="text-sm font-medium text-amber-800 mb-2">Important Guidelines:</h4>
          <ul className="text-xs text-amber-700 space-y-1">
            <li>• Only use test keys and dummy data</li>
            <li>• Never enter real private keys</li>
            <li>• This tool is for learning purposes only</li>
            <li>• Ensure you understand the security implications</li>
          </ul>
        </div>

        <div className="flex space-x-3 mt-6">
          <Button
            onClick={handleUnderstand}
            className="flex-1 bg-red-600 hover:bg-red-700 text-white"
          >
            I Understand
          </Button>
          <Button
            onClick={handleCancel}
            variant="outline"
            className="border-slate-300 text-slate-700 hover:bg-slate-50"
          >
            Cancel
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
