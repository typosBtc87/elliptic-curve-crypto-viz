import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertTriangle, Copy, Puzzle, Target, Trophy, Clock, Cpu } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface PuzzleData {
  puzzle: number;
  bits: number;
  status: string;
  reward: string;
  address: string;
  range: { start: string; end: string };
  privateKey?: string;
  solvedDate?: string;
}

export function PuzzleSolver() {
  const [startRange, setStartRange] = useState("20000000000000000");
  const [endRange, setEndRange] = useState("3ffffffffffffffff");
  const [targetAddress, setTargetAddress] = useState("13zb1hQbWVsc2S7ZTZnP2G4undNNpdh5so");
  const [searchMode, setSearchMode] = useState<"sequential" | "random" | "hybrid">("sequential");
  const [bitLength, setBitLength] = useState(66);
  const [maxIterations, setMaxIterations] = useState(10000);
  const { toast } = useToast();

  // Fetch known puzzles
  const { data: puzzlesData } = useQuery({
    queryKey: ["/api/crypto/puzzles"],
    queryFn: () => apiRequest("/api/crypto/puzzles", "GET"),
  });

  const solvePuzzleMutation = useMutation({
    mutationFn: (data: any) => apiRequest("/api/crypto/solve-puzzle", "POST", data),
    onSuccess: (data: any) => {
      if (data.found) {
        toast({
          title: "🎉 Private Key Found!",
          description: `Found private key in ${data.iterations} iterations`,
        });
      } else {
        toast({
          title: "Search Complete",
          description: `Searched ${data.iterations} keys without finding target`,
        });
      }
    },
    onError: (error: any) => {
      toast({
        title: "Search Failed",
        description: error.message || "Failed to solve puzzle",
        variant: "destructive",
      });
    },
  });

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied",
      description: "Copied to clipboard",
    });
  };

  const loadPuzzle = (puzzle: PuzzleData) => {
    setStartRange(puzzle.range.start);
    setEndRange(puzzle.range.end);
    setTargetAddress(puzzle.address);
    setBitLength(puzzle.bits);
  };

  const handleSolvePuzzle = () => {
    solvePuzzleMutation.mutate({
      startRange,
      endRange,
      targetAddress,
      searchMode,
      bitLength,
      maxIterations,
    });
  };

  return (
    <div className="space-y-6">
      {/* Security Warning */}
      <Card className="border-amber-200 bg-amber-50/50 dark:border-amber-800 dark:bg-amber-950/50">
        <CardHeader className="pb-3">
          <div className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-amber-600" />
            <CardTitle className="text-amber-900 dark:text-amber-100">Bitcoin Puzzle Challenge</CardTitle>
          </div>
        </CardHeader>
        <CardContent className="text-sm text-amber-800 dark:text-amber-200">
          This tool demonstrates brute-force search techniques for Bitcoin puzzles. Real puzzles require 
          significant computational resources and advanced algorithms. Use for educational purposes only.
        </CardContent>
      </Card>

      {/* Known Puzzles Database */}
      {puzzlesData && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Trophy className="h-5 w-5" />
              Bitcoin Puzzles Database
            </CardTitle>
            <CardDescription>
              Known Bitcoin puzzles with their ranges and current status
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="mb-4">
              <div className="flex gap-4 text-sm text-muted-foreground">
                <span>Total Unsolved: {(puzzlesData as any).totalUnsolved}</span>
                <span>Total Reward: {(puzzlesData as any).totalReward}</span>
              </div>
            </div>
            
            <div className="grid gap-3">
              {(puzzlesData as any).puzzles.map((puzzle: PuzzleData) => (
                <div
                  key={puzzle.puzzle}
                  className="flex items-center justify-between p-3 border rounded-lg hover:bg-muted/50 cursor-pointer"
                  onClick={() => loadPuzzle(puzzle)}
                >
                  <div className="flex items-center gap-3">
                    <Badge 
                      variant={puzzle.status === "SOLVED" ? "default" : "secondary"}
                      className={puzzle.status === "SOLVED" ? "bg-green-500" : ""}
                    >
                      Puzzle #{puzzle.puzzle}
                    </Badge>
                    <div className="space-y-1">
                      <div className="font-medium">{puzzle.bits}-bit • {puzzle.reward}</div>
                      <div className="text-xs text-muted-foreground font-mono">
                        {puzzle.address}
                      </div>
                    </div>
                  </div>
                  <div className="text-right text-sm">
                    <div className={puzzle.status === "SOLVED" ? "text-green-600" : "text-orange-600"}>
                      {puzzle.status}
                    </div>
                    {puzzle.solvedDate && (
                      <div className="text-xs text-muted-foreground">
                        {puzzle.solvedDate}
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Puzzle Solver Configuration */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Puzzle className="h-5 w-5" />
            Puzzle Solver Configuration
          </CardTitle>
          <CardDescription>
            Configure the brute-force search parameters
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="startRange">Start Range (hex)</Label>
              <Input
                id="startRange"
                value={startRange}
                onChange={(e) => setStartRange(e.target.value)}
                className="font-mono text-sm"
                placeholder="Start of search range"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="endRange">End Range (hex)</Label>
              <Input
                id="endRange"
                value={endRange}
                onChange={(e) => setEndRange(e.target.value)}
                className="font-mono text-sm"
                placeholder="End of search range"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="targetAddress">Target Bitcoin Address</Label>
            <Input
              id="targetAddress"
              value={targetAddress}
              onChange={(e) => setTargetAddress(e.target.value)}
              className="font-mono text-sm"
              placeholder="Bitcoin address to find"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="searchMode">Search Mode</Label>
              <Select value={searchMode} onValueChange={(value: any) => setSearchMode(value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="sequential">Sequential</SelectItem>
                  <SelectItem value="random">Random</SelectItem>
                  <SelectItem value="hybrid">Hybrid</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="bitLength">Bit Length</Label>
              <Input
                id="bitLength"
                type="number"
                value={bitLength}
                onChange={(e) => setBitLength(parseInt(e.target.value))}
                min="1"
                max="256"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="maxIterations">Max Iterations</Label>
              <Input
                id="maxIterations"
                type="number"
                value={maxIterations}
                onChange={(e) => setMaxIterations(parseInt(e.target.value))}
                min="1000"
                max="1000000"
              />
            </div>
          </div>

          <Button 
            onClick={handleSolvePuzzle}
            disabled={!startRange || !endRange || !targetAddress || solvePuzzleMutation.isPending}
            className="w-full"
          >
            {solvePuzzleMutation.isPending ? "Searching..." : "Start Puzzle Search"}
          </Button>
        </CardContent>
      </Card>

      {/* Search Results */}
      {solvePuzzleMutation.data && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Target className="h-5 w-5" />
              Search Results
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm">Iterations: {(solvePuzzleMutation.data as any).iterations}</span>
              </div>
              <div className="flex items-center gap-2">
                <Cpu className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm">Progress: {(solvePuzzleMutation.data as any).progress}%</span>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant={(solvePuzzleMutation.data as any).found ? "default" : "secondary"}>
                  {(solvePuzzleMutation.data as any).found ? "FOUND" : "NOT FOUND"}
                </Badge>
              </div>
            </div>

            {(solvePuzzleMutation.data as any).progress > 0 && (
              <Progress value={(solvePuzzleMutation.data as any).progress} className="w-full" />
            )}

            {(solvePuzzleMutation.data as any).found && (
              <Alert className="border-green-200 bg-green-50 dark:border-green-800 dark:bg-green-950">
                <Trophy className="h-4 w-4" />
                <AlertDescription>
                  <div className="space-y-2">
                    <div className="font-medium">🎉 Private Key Found!</div>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <Label className="text-xs">Private Key</Label>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => copyToClipboard((solvePuzzleMutation.data as any).privateKey)}
                        >
                          <Copy className="h-3 w-3" />
                        </Button>
                      </div>
                      <div className="font-mono text-sm bg-background p-2 rounded border break-all">
                        {(solvePuzzleMutation.data as any).privateKey}
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <Label className="text-xs">Address Found</Label>
                      <div className="font-mono text-sm bg-background p-2 rounded border break-all">
                        {(solvePuzzleMutation.data as any).address}
                      </div>
                    </div>
                  </div>
                </AlertDescription>
              </Alert>
            )}

            <div className="text-xs text-muted-foreground space-y-1">
              <div>Search Mode: {(solvePuzzleMutation.data as any).searchMode}</div>
              <div>Bit Length: {(solvePuzzleMutation.data as any).bitLength}</div>
              <div>Range Size: {(solvePuzzleMutation.data as any).range?.size || "N/A"}</div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}