import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Shield, Clock, CheckCircle, XCircle, Info } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface VerificationResult {
  isValid: boolean;
  validations: {
    messageHashValid: boolean;
    signatureFormatValid: boolean;
    publicKeyValid: boolean;
    ecdsaVerification: boolean;
  };
}

export function SignatureVerification() {
  const [messageHash, setMessageHash] = useState("");
  const [rValue, setRValue] = useState("");
  const [sValue, setSValue] = useState("");
  const [publicKey, setPublicKey] = useState("");
  const [result, setResult] = useState<VerificationResult | null>(null);
  const { toast } = useToast();

  const verifyMutation = useMutation({
    mutationFn: async (data: { messageHash: string; rValue: string; sValue: string; publicKey: string }) => {
      const response = await apiRequest("POST", "/api/crypto/verify-signature", data);
      return response.json();
    },
    onSuccess: (data) => {
      setResult(data);
      toast({
        title: data.isValid ? "Signature Valid" : "Signature Invalid",
        description: data.isValid 
          ? "The signature verification passed all checks." 
          : "The signature verification failed.",
        variant: data.isValid ? "default" : "destructive",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Verification Failed",
        description: error.message || "Unable to verify signature",
        variant: "destructive",
      });
    },
  });

  const handleVerify = () => {
    if (!messageHash.trim() || !rValue.trim() || !sValue.trim() || !publicKey.trim()) {
      toast({
        title: "Input Required",
        description: "Please fill in all fields",
        variant: "destructive",
      });
      return;
    }

    verifyMutation.mutate({
      messageHash: messageHash.trim(),
      rValue: rValue.trim(),
      sValue: sValue.trim(),
      publicKey: publicKey.trim(),
    });
  };

  const ValidationStatus = ({ isValid, label }: { isValid: boolean | null; label: string }) => {
    if (isValid === null) {
      return (
        <div className="flex items-center justify-between text-sm">
          <span className="text-slate-600">{label}:</span>
          <span className="text-slate-400">Pending</span>
        </div>
      );
    }

    return (
      <div className="flex items-center justify-between text-sm">
        <span className="text-slate-600">{label}:</span>
        <span className={`font-medium flex items-center gap-1 ${isValid ? "text-emerald-600" : "text-red-600"}`}>
          {isValid ? <CheckCircle size={14} /> : <XCircle size={14} />}
          {isValid ? "Valid" : "Invalid"}
        </span>
      </div>
    );
  };

  return (
    <section className="bg-white rounded-xl border border-slate-200 p-6 mb-8">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-xl font-semibold text-slate-900">Signature Verification</h2>
          <p className="text-sm text-slate-600 mt-1">Verify ECDSA signatures using secp256k1</p>
        </div>
        <Button variant="ghost" size="sm" className="text-slate-400 hover:text-slate-600">
          <Info size={16} />
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Input Fields */}
        <div className="space-y-4">
          <div>
            <Label className="text-sm font-medium text-slate-700 mb-2">Message Hash</Label>
            <Textarea
              value={messageHash}
              onChange={(e) => setMessageHash(e.target.value)}
              className="font-mono text-sm resize-none"
              rows={2}
              placeholder="Enter message hash (SHA-256)"
            />
          </div>

          <div>
            <Label className="text-sm font-medium text-slate-700 mb-2">Signature (r,s)</Label>
            <div className="space-y-2">
              <Input
                value={rValue}
                onChange={(e) => setRValue(e.target.value)}
                className="font-mono text-sm"
                placeholder="r value (hex)"
              />
              <Input
                value={sValue}
                onChange={(e) => setSValue(e.target.value)}
                className="font-mono text-sm"
                placeholder="s value (hex)"
              />
            </div>
          </div>

          <div>
            <Label className="text-sm font-medium text-slate-700 mb-2">Public Key</Label>
            <Textarea
              value={publicKey}
              onChange={(e) => setPublicKey(e.target.value)}
              className="font-mono text-sm resize-none"
              rows={2}
              placeholder="Public key (compressed or uncompressed)"
            />
          </div>

          <Button
            onClick={handleVerify}
            disabled={verifyMutation.isPending}
            className="w-full bg-crypto-blue hover:bg-blue-700"
          >
            <Shield size={16} className="mr-2" />
            {verifyMutation.isPending ? "Verifying..." : "Verify Signature"}
          </Button>
        </div>

        {/* Verification Results */}
        <div>
          <div className="mb-4">
            <h3 className="text-sm font-medium text-slate-700 mb-3">Verification Status</h3>
            {result ? (
              <Card className={`border-2 ${result.isValid ? "border-emerald-200 bg-emerald-50" : "border-red-200 bg-red-50"}`}>
                <CardContent className="p-6 text-center">
                  {result.isValid ? (
                    <CheckCircle size={48} className="text-emerald-600 mx-auto mb-3" />
                  ) : (
                    <XCircle size={48} className="text-red-600 mx-auto mb-3" />
                  )}
                  <h4 className={`font-semibold mb-2 ${result.isValid ? "text-emerald-900" : "text-red-900"}`}>
                    Signature {result.isValid ? "Valid" : "Invalid"}
                  </h4>
                  <p className={`text-sm ${result.isValid ? "text-emerald-700" : "text-red-700"}`}>
                    {result.isValid 
                      ? "The signature is cryptographically valid"
                      : "The signature failed verification checks"
                    }
                  </p>
                </CardContent>
              </Card>
            ) : (
              <Card className="border-2 border-dashed border-slate-300">
                <CardContent className="p-6 text-center">
                  <Clock size={48} className="text-slate-400 mx-auto mb-3" />
                  <p className="text-slate-600">Click "Verify Signature" to check validity</p>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Signature Components Analysis */}
          <div className="space-y-3">
            <Card>
              <CardContent className="p-3">
                <ValidationStatus 
                  isValid={result?.validations.messageHashValid ?? null}
                  label="Message Hash Valid"
                />
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-3">
                <ValidationStatus 
                  isValid={result?.validations.signatureFormatValid ?? null}
                  label="Signature Format Valid"
                />
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-3">
                <ValidationStatus 
                  isValid={result?.validations.publicKeyValid ?? null}
                  label="Public Key Valid"
                />
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-3">
                <ValidationStatus 
                  isValid={result?.validations.ecdsaVerification ?? null}
                  label="ECDSA Verification"
                />
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}
