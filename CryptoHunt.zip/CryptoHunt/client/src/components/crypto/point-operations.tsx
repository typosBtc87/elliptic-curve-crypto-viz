import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { Calculator, ArrowUp, Info } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface PointOperationResult {
  x?: string;
  y?: string;
  isValid?: boolean;
  error?: string;
}

const GENERATOR_POINT = {
  x: "79BE667EF9DCBBAC55A06295CE870B07029BFCDB2DCE28D959F2815B16F81798",
  y: "483ADA7726A3C4655DA4FBFC0E1108A8FD17B448A68554199C47D08FFB10D4B8",
};

export function PointOperations() {
  const [operation, setOperation] = useState("add");
  const [point1X, setPoint1X] = useState("");
  const [point1Y, setPoint1Y] = useState("");
  const [point2X, setPoint2X] = useState("");
  const [point2Y, setPoint2Y] = useState("");
  const [scalar, setScalar] = useState("");
  const [result, setResult] = useState<PointOperationResult | null>(null);
  const { toast } = useToast();

  const operationMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("POST", "/api/crypto/point-operation", data);
      return response.json();
    },
    onSuccess: (data) => {
      setResult(data);
      if (data.error) {
        toast({
          title: "Operation Failed",
          description: data.error,
          variant: "destructive",
        });
      } else {
        toast({
          title: "Operation Complete",
          description: "Point operation executed successfully.",
        });
      }
    },
    onError: (error: any) => {
      toast({
        title: "Operation Failed",
        description: error.message || "Unable to execute operation",
        variant: "destructive",
      });
    },
  });

  const handleExecuteOperation = () => {
    const operationData = {
      operation,
      point1X: point1X.replace(/^0x/, ""),
      point1Y: point1Y.replace(/^0x/, ""),
      point2X: point2X.replace(/^0x/, ""),
      point2Y: point2Y.replace(/^0x/, ""),
      scalar: scalar.replace(/^0x/, ""),
    };

    // Validate required fields based on operation
    switch (operation) {
      case "add":
        if (!point1X || !point1Y || !point2X || !point2Y) {
          toast({
            title: "Input Required",
            description: "Point addition requires both points",
            variant: "destructive",
          });
          return;
        }
        break;
      case "double":
      case "validate":
        if (!point1X || !point1Y) {
          toast({
            title: "Input Required",
            description: "This operation requires Point 1 coordinates",
            variant: "destructive",
          });
          return;
        }
        break;
      case "multiply":
      case "divide":
        if (!point1X || !point1Y || !scalar) {
          toast({
            title: "Input Required",
            description: "This operation requires Point 1 and a scalar value",
            variant: "destructive",
          });
          return;
        }
        break;
    }

    operationMutation.mutate(operationData);
  };

  const useGeneratorPoint = () => {
    setPoint1X(GENERATOR_POINT.x);
    setPoint1Y(GENERATOR_POINT.y);
    toast({
      title: "Generator Point Loaded",
      description: "Secp256k1 generator point coordinates have been loaded into Point 1",
    });
  };

  const needsPoint2 = operation === "add";
  const needsScalar = operation === "multiply" || operation === "divide";

  return (
    <section className="bg-white rounded-xl border border-slate-200 p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-xl font-semibold text-slate-900">Elliptic Curve Point Operations</h2>
          <p className="text-sm text-slate-600 mt-1">Perform mathematical operations on secp256k1 curve points</p>
        </div>
        <Button variant="ghost" size="sm" className="text-slate-400 hover:text-slate-600">
          <Info size={16} />
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Operation Selector & Inputs */}
        <div>
          <div className="mb-4">
            <Label className="text-sm font-medium text-slate-700 mb-2">Operation Type</Label>
            <Select value={operation} onValueChange={setOperation}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="add">Point Addition (P1 + P2)</SelectItem>
                <SelectItem value="double">Point Doubling (2 * P)</SelectItem>
                <SelectItem value="multiply">Scalar Multiplication (k * P)</SelectItem>
                <SelectItem value="divide">Point Division (P / k)</SelectItem>
                <SelectItem value="validate">Curve Validation</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-4">
            <div>
              <Label className="text-sm font-medium text-slate-700 mb-2">Point 1 (x, y)</Label>
              <div className="grid grid-cols-1 gap-2">
                <Input
                  value={point1X}
                  onChange={(e) => setPoint1X(e.target.value)}
                  className="font-mono text-sm"
                  placeholder="X coordinate (hex)"
                />
                <Input
                  value={point1Y}
                  onChange={(e) => setPoint1Y(e.target.value)}
                  className="font-mono text-sm"
                  placeholder="Y coordinate (hex)"
                />
              </div>
            </div>

            {needsPoint2 && (
              <div>
                <Label className="text-sm font-medium text-slate-700 mb-2">Point 2 (x, y)</Label>
                <div className="grid grid-cols-1 gap-2">
                  <Input
                    value={point2X}
                    onChange={(e) => setPoint2X(e.target.value)}
                    className="font-mono text-sm"
                    placeholder="X coordinate (hex)"
                  />
                  <Input
                    value={point2Y}
                    onChange={(e) => setPoint2Y(e.target.value)}
                    className="font-mono text-sm"
                    placeholder="Y coordinate (hex)"
                  />
                </div>
              </div>
            )}

            {needsScalar && (
              <div>
                <Label className="text-sm font-medium text-slate-700 mb-2">Scalar Value</Label>
                <Input
                  value={scalar}
                  onChange={(e) => setScalar(e.target.value)}
                  className="font-mono text-sm"
                  placeholder="Scalar value (hex)"
                />
              </div>
            )}

            <Button
              onClick={handleExecuteOperation}
              disabled={operationMutation.isPending}
              className="w-full bg-crypto-blue hover:bg-blue-700"
            >
              <Calculator size={16} className="mr-2" />
              {operationMutation.isPending ? "Processing..." : "Execute Operation"}
            </Button>
          </div>
        </div>

        {/* Results Display */}
        <div>
          <div className="mb-4">
            <h3 className="text-sm font-medium text-slate-700 mb-3">Operation Results</h3>
            {result ? (
              <div className="space-y-3">
                {result.error ? (
                  <Card className="border-red-200 bg-red-50">
                    <CardContent className="p-4">
                      <p className="text-red-700 text-sm">{result.error}</p>
                    </CardContent>
                  </Card>
                ) : operation === "validate" ? (
                  <Card className={`border-2 ${result.isValid ? "border-emerald-200 bg-emerald-50" : "border-red-200 bg-red-50"}`}>
                    <CardContent className="p-4">
                      <p className={`font-medium ${result.isValid ? "text-emerald-700" : "text-red-700"}`}>
                        Point is {result.isValid ? "valid" : "invalid"} on secp256k1 curve
                      </p>
                    </CardContent>
                  </Card>
                ) : (
                  <>
                    <div>
                      <Label className="text-xs font-medium text-slate-600">X Coordinate</Label>
                      <Card className="mt-1">
                        <CardContent className="p-3">
                          <code className="text-xs font-mono text-slate-900 break-all">
                            {result.x}
                          </code>
                        </CardContent>
                      </Card>
                    </div>
                    <div>
                      <Label className="text-xs font-medium text-slate-600">Y Coordinate</Label>
                      <Card className="mt-1">
                        <CardContent className="p-3">
                          <code className="text-xs font-mono text-slate-900 break-all">
                            {result.y}
                          </code>
                        </CardContent>
                      </Card>
                    </div>
                  </>
                )}
              </div>
            ) : (
              <Card className="border-2 border-dashed border-slate-300">
                <CardContent className="p-6 text-center">
                  <Calculator size={48} className="text-slate-400 mx-auto mb-3" />
                  <p className="text-slate-600">Select operation and input values to see results</p>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Generator Point Reference */}
          <Card className="bg-blue-50 border-blue-200">
            <CardContent className="p-4">
              <h4 className="text-sm font-medium text-blue-900 mb-3">Secp256k1 Generator Point (G)</h4>
              <div className="space-y-2 text-xs">
                <div>
                  <span className="text-blue-700 font-medium">Gx:</span>
                  <code className="font-mono text-blue-900 ml-2 break-all block">
                    {GENERATOR_POINT.x}
                  </code>
                </div>
                <div>
                  <span className="text-blue-700 font-medium">Gy:</span>
                  <code className="font-mono text-blue-900 ml-2 break-all block">
                    {GENERATOR_POINT.y}
                  </code>
                </div>
              </div>
              <Button
                onClick={useGeneratorPoint}
                variant="outline"
                size="sm"
                className="mt-3 text-xs text-blue-700 hover:text-blue-900 border-blue-300"
              >
                <ArrowUp size={12} className="mr-1" />
                Use as Point 1
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}
