import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, Copy, Key, MapPin } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

export function AddressGenerator() {
  const [publicKey, setPublicKey] = useState("");
  const [addressType, setAddressType] = useState<"legacy" | "segwit" | "bech32">("legacy");
  const [privateKey, setPrivateKey] = useState("");
  const { toast } = useToast();

  const generateAddressMutation = useMutation({
    mutationFn: (data: { publicKey: string; addressType: string }) =>
      apiRequest("/api/crypto/generate-address", "POST", data),
    onSuccess: () => {
      toast({
        title: "Address Generated",
        description: "Bitcoin address generated successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Generation Failed",
        description: error.message || "Failed to generate address",
        variant: "destructive",
      });
    },
  });

  const privateToAddressMutation = useMutation({
    mutationFn: (data: { privateKey: string; addressType: string }) =>
      apiRequest("/api/crypto/private-to-address", "POST", data),
    onSuccess: () => {
      toast({
        title: "Address Generated",
        description: "Address generated from private key successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Generation Failed",
        description: error.message || "Failed to generate address from private key",
        variant: "destructive",
      });
    },
  });

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied",
      description: "Copied to clipboard",
    });
  };

  const handleGenerateFromPublicKey = () => {
    generateAddressMutation.mutate({ publicKey, addressType });
  };

  const handleGenerateFromPrivateKey = () => {
    privateToAddressMutation.mutate({ privateKey, addressType });
  };

  return (
    <div className="space-y-6">
      {/* Security Warning */}
      <Card className="border-amber-200 bg-amber-50/50 dark:border-amber-800 dark:bg-amber-950/50">
        <CardHeader className="pb-3">
          <div className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-amber-600" />
            <CardTitle className="text-amber-900 dark:text-amber-100">Security Notice</CardTitle>
          </div>
        </CardHeader>
        <CardContent className="text-sm text-amber-800 dark:text-amber-200">
          Bitcoin address generation tools are for educational purposes. Never share private keys or use this for real Bitcoin transactions.
        </CardContent>
      </Card>

      {/* Generate from Public Key */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MapPin className="h-5 w-5" />
            Generate Address from Public Key
          </CardTitle>
          <CardDescription>
            Convert a secp256k1 public key to different Bitcoin address formats
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="publicKey">Public Key (compressed or uncompressed)</Label>
            <Textarea
              id="publicKey"
              placeholder="Enter public key (hex format, with or without 0x prefix)"
              value={publicKey}
              onChange={(e) => setPublicKey(e.target.value)}
              className="font-mono text-sm"
              rows={2}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="addressType">Address Type</Label>
            <Select value={addressType} onValueChange={(value: any) => setAddressType(value)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="legacy">Legacy (P2PKH) - starts with '1'</SelectItem>
                <SelectItem value="segwit">SegWit (P2SH-P2WPKH) - starts with '3'</SelectItem>
                <SelectItem value="bech32">Native SegWit (P2WPKH) - starts with 'bc1'</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Button 
            onClick={handleGenerateFromPublicKey}
            disabled={!publicKey || generateAddressMutation.isPending}
            className="w-full"
          >
            {generateAddressMutation.isPending ? "Generating..." : "Generate Address"}
          </Button>

          {generateAddressMutation.data && (
            <div className="space-y-3 rounded-lg border bg-muted/50 p-4">
              <div className="flex items-center justify-between">
                <Badge variant="secondary">{(generateAddressMutation.data as any).addressType}</Badge>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => copyToClipboard((generateAddressMutation.data as any).address)}
                >
                  <Copy className="h-4 w-4" />
                </Button>
              </div>
              <div className="space-y-2">
                <Label className="text-xs font-medium">Bitcoin Address</Label>
                <div className="font-mono text-sm break-all bg-background p-2 rounded border">
                  {(generateAddressMutation.data as any).address}
                </div>
              </div>
              {(generateAddressMutation.data as any).publicKeyHash && (
                <div className="space-y-2">
                  <Label className="text-xs font-medium">Public Key Hash (HASH160)</Label>
                  <div className="font-mono text-sm break-all bg-background p-2 rounded border">
                    {(generateAddressMutation.data as any).publicKeyHash}
                  </div>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      <Separator />

      {/* Generate from Private Key */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Key className="h-5 w-5" />
            Generate Address from Private Key
          </CardTitle>
          <CardDescription>
            Generate public key and address from a private key
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="privateKey">Private Key (hex format)</Label>
            <Input
              id="privateKey"
              type="password"
              placeholder="Enter private key (64 hex characters)"
              value={privateKey}
              onChange={(e) => setPrivateKey(e.target.value)}
              className="font-mono text-sm"
            />
          </div>

          <Button 
            onClick={handleGenerateFromPrivateKey}
            disabled={!privateKey || privateToAddressMutation.isPending}
            className="w-full"
          >
            {privateToAddressMutation.isPending ? "Generating..." : "Generate from Private Key"}
          </Button>

          {privateToAddressMutation.data && (
            <div className="space-y-3 rounded-lg border bg-muted/50 p-4">
              <div className="flex items-center justify-between">
                <Badge variant="secondary">{(privateToAddressMutation.data as any).addressType}</Badge>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => copyToClipboard(JSON.stringify(privateToAddressMutation.data, null, 2))}
                >
                  <Copy className="h-4 w-4" />
                </Button>
              </div>
              
              <div className="space-y-3">
                <div className="space-y-2">
                  <Label className="text-xs font-medium">Private Key</Label>
                  <div className="font-mono text-sm break-all bg-background p-2 rounded border">
                    {(privateToAddressMutation.data as any).privateKey}
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label className="text-xs font-medium">Public Key (Compressed)</Label>
                  <div className="font-mono text-sm break-all bg-background p-2 rounded border">
                    {(privateToAddressMutation.data as any).publicKey}
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label className="text-xs font-medium">Bitcoin Address</Label>
                  <div className="font-mono text-sm break-all bg-background p-2 rounded border">
                    {(privateToAddressMutation.data as any).address}
                  </div>
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}