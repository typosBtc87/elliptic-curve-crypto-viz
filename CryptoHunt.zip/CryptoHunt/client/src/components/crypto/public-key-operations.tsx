import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Copy, RefreshCw, CheckCircle, Info, Clipboard } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface PublicKeyResult {
  compressed: string;
  uncompressed: string;
  coordinates: { x: string; y: string };
  isValid: boolean;
  format: string;
  length: number;
}

export function PublicKeyOperations() {
  const [publicKey, setPublicKey] = useState("");
  const [result, setResult] = useState<PublicKeyResult | null>(null);
  const { toast } = useToast();

  const convertMutation = useMutation({
    mutationFn: async (data: { publicKey: string }) => {
      const response = await apiRequest("POST", "/api/crypto/public-key", data);
      return response.json();
    },
    onSuccess: (data) => {
      setResult(data);
      toast({
        title: "Conversion Complete",
        description: "Public key has been successfully processed.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Conversion Failed",
        description: error.message || "Invalid public key format",
        variant: "destructive",
      });
    },
  });

  const copyToClipboard = async (text: string, label: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast({
        title: "Copied!",
        description: `${label} copied to clipboard`,
      });
    } catch (error) {
      toast({
        title: "Copy Failed",
        description: "Unable to copy to clipboard",
        variant: "destructive",
      });
    }
  };

  const pasteFromClipboard = async () => {
    try {
      const text = await navigator.clipboard.readText();
      setPublicKey(text.trim());
    } catch (error) {
      toast({
        title: "Paste Failed",
        description: "Unable to paste from clipboard",
        variant: "destructive",
      });
    }
  };

  const handleConvert = () => {
    if (!publicKey.trim()) {
      toast({
        title: "Input Required",
        description: "Please enter a public key",
        variant: "destructive",
      });
      return;
    }
    convertMutation.mutate({ publicKey: publicKey.trim() });
  };

  const copyAllResults = () => {
    if (!result) return;
    const allResults = `Compressed: ${result.compressed}\nUncompressed: ${result.uncompressed}\nX: ${result.coordinates.x}\nY: ${result.coordinates.y}`;
    copyToClipboard(allResults, "All results");
  };

  return (
    <section className="bg-white rounded-xl border border-slate-200 p-6 mb-8">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-xl font-semibold text-slate-900">Public Key Operations</h2>
          <p className="text-sm text-slate-600 mt-1">Convert between compressed and uncompressed public key formats</p>
        </div>
        <Button
          variant="ghost"
          size="sm"
          className="text-slate-400 hover:text-slate-600"
        >
          <Info size={16} />
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Input Section */}
        <div>
          <Label className="text-sm font-medium text-slate-700 mb-2 flex items-center gap-2">
            Public Key Input
            <span className="text-slate-400 text-xs">(Compressed or Uncompressed)</span>
          </Label>
          <div className="relative">
            <Textarea
              value={publicKey}
              onChange={(e) => setPublicKey(e.target.value)}
              className="font-mono text-sm resize-none"
              rows={3}
              placeholder="03a61fc84b6429f07fc0edf25265ef7a0ced3cd9a0edea85e9f58b50b5d73f66e7"
            />
            <Button
              variant="ghost"
              size="sm"
              className="absolute top-2 right-2 p-1 h-auto"
              onClick={pasteFromClipboard}
            >
              <Clipboard size={14} />
            </Button>
          </div>
          <div className="flex items-center mt-2 text-xs text-slate-500">
            <Info size={12} className="mr-1" />
            Supports both 02/03 (compressed) and 04 (uncompressed) prefixes
          </div>

          {/* Format Detection */}
          {result && (
            <div className="mt-4 p-3 bg-slate-50 rounded-lg">
              <div className="flex items-center justify-between text-sm">
                <span className="text-slate-600">Detected Format:</span>
                <Badge variant={result.format === "compressed" ? "default" : "secondary"}>
                  {result.format === "compressed" ? "Compressed" : "Uncompressed"} ({result.length} bytes)
                </Badge>
              </div>
              <div className="flex items-center justify-between text-sm mt-2">
                <span className="text-slate-600">On Curve:</span>
                <span className={`font-medium flex items-center gap-1 ${result.isValid ? "text-emerald-600" : "text-red-600"}`}>
                  <CheckCircle size={12} />
                  {result.isValid ? "Valid" : "Invalid"}
                </span>
              </div>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex space-x-3 mt-4">
            <Button
              onClick={handleConvert}
              disabled={convertMutation.isPending}
              className="flex-1 bg-crypto-blue hover:bg-blue-700"
            >
              {convertMutation.isPending ? (
                <RefreshCw size={16} className="mr-2 animate-spin" />
              ) : (
                <RefreshCw size={16} className="mr-2" />
              )}
              Convert Format
            </Button>
            <Button
              variant="outline"
              onClick={handleConvert}
              disabled={convertMutation.isPending}
            >
              <CheckCircle size={16} className="mr-2" />
              Validate
            </Button>
          </div>
        </div>

        {/* Results Section */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <Label className="text-sm font-medium text-slate-700">Results</Label>
            {result && (
              <Button
                variant="ghost"
                size="sm"
                onClick={copyAllResults}
                className="text-xs text-crypto-blue hover:text-blue-700"
              >
                <Copy size={12} className="mr-1" />
                Copy All
              </Button>
            )}
          </div>

          {result ? (
            <>
              {/* Compressed Result */}
              <div className="mb-4">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-medium text-slate-600">Compressed Public Key</span>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => copyToClipboard(result.compressed, "Compressed public key")}
                    className="text-xs text-slate-400 hover:text-slate-600 p-0 h-auto"
                  >
                    <Copy size={12} />
                  </Button>
                </div>
                <Card>
                  <CardContent className="p-3">
                    <code className="text-xs font-mono text-slate-900 break-all">
                      {result.compressed}
                    </code>
                  </CardContent>
                </Card>
              </div>

              {/* Uncompressed Result */}
              <div className="mb-4">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-medium text-slate-600">Uncompressed Public Key</span>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => copyToClipboard(result.uncompressed, "Uncompressed public key")}
                    className="text-xs text-slate-400 hover:text-slate-600 p-0 h-auto"
                  >
                    <Copy size={12} />
                  </Button>
                </div>
                <Card>
                  <CardContent className="p-3">
                    <code className="text-xs font-mono text-slate-900 break-all">
                      {result.uncompressed}
                    </code>
                  </CardContent>
                </Card>
              </div>

              {/* Coordinate Display */}
              <div className="space-y-3">
                <div>
                  <span className="text-xs font-medium text-slate-600">X Coordinate</span>
                  <Card className="mt-1">
                    <CardContent className="p-2">
                      <code className="text-xs font-mono text-slate-900">
                        {result.coordinates.x}
                      </code>
                    </CardContent>
                  </Card>
                </div>
                <div>
                  <span className="text-xs font-medium text-slate-600">Y Coordinate</span>
                  <Card className="mt-1">
                    <CardContent className="p-2">
                      <code className="text-xs font-mono text-slate-900">
                        {result.coordinates.y}
                      </code>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </>
          ) : (
            <Card className="border-2 border-dashed">
              <CardContent className="p-6 text-center">
                <div className="text-slate-400 mb-3">
                  <RefreshCw size={32} className="mx-auto" />
                </div>
                <p className="text-slate-600">Click "Convert Format" to process a public key</p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </section>
  );
}
