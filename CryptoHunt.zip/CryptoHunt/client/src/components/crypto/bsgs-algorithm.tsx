import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertTriangle, Copy, Zap, Target, Clock, TrendingUp } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

export function BsgsAlgorithm() {
  const [targetPublicKey, setTargetPublicKey] = useState("02145d2611c823a396ef6712ce0f712f09b9b4f3135e3e0aa3230fb9b6d08d1e16");
  const [startRange, setStartRange] = useState("20000000000000000");
  const [endRange, setEndRange] = useState("3ffffffffffffffff");
  const [babySteps, setBabySteps] = useState(100000);
  const { toast } = useToast();

  const bsgsMutation = useMutation({
    mutationFn: (data: any) => apiRequest("/api/crypto/bsgs", "POST", data),
    onSuccess: (data: any) => {
      if (data.found) {
        toast({
          title: "🎯 Private Key Found!",
          description: `BSGS found private key in ${data.iterations} iterations`,
        });
      } else {
        toast({
          title: "Search Complete",
          description: `BSGS completed ${data.iterations} iterations without finding target`,
        });
      }
    },
    onError: (error: any) => {
      toast({
        title: "BSGS Failed",
        description: error.message || "BSGS algorithm failed",
        variant: "destructive",
      });
    },
  });

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied",
      description: "Copied to clipboard",
    });
  };

  const handleRunBsgs = () => {
    bsgsMutation.mutate({
      targetPublicKey,
      startRange,
      endRange,
      babySteps,
    });
  };

  const loadExample = () => {
    setTargetPublicKey("02145d2611c823a396ef6712ce0f712f09b9b4f3135e3e0aa3230fb9b6d08d1e16");
    setStartRange("20000000000000000");
    setEndRange("3ffffffffffffffff");
    setBabySteps(100000);
  };

  return (
    <div className="space-y-6">
      {/* Algorithm Info */}
      <Card className="border-blue-200 bg-blue-50/50 dark:border-blue-800 dark:bg-blue-950/50">
        <CardHeader className="pb-3">
          <div className="flex items-center gap-2">
            <Zap className="h-5 w-5 text-blue-600" />
            <CardTitle className="text-blue-900 dark:text-blue-100">Baby-Step Giant-Step Algorithm</CardTitle>
          </div>
        </CardHeader>
        <CardContent className="text-sm text-blue-800 dark:text-blue-200">
          <div className="space-y-2">
            <p>BSGS is a memory-time tradeoff algorithm for solving discrete logarithm problems.</p>
            <p>Best suited for puzzles with known public keys. Time complexity: O(√n), Space: O(√n)</p>
            <Button variant="outline" size="sm" onClick={loadExample} className="mt-2">
              Load Example (Puzzle #66)
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* BSGS Configuration */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="h-5 w-5" />
            BSGS Configuration
          </CardTitle>
          <CardDescription>
            Configure the Baby-Step Giant-Step algorithm parameters
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="targetPublicKey">Target Public Key</Label>
            <Textarea
              id="targetPublicKey"
              placeholder="Enter the target public key (compressed format)"
              value={targetPublicKey}
              onChange={(e) => setTargetPublicKey(e.target.value)}
              className="font-mono text-sm"
              rows={2}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="bsgsStartRange">Start Range (hex)</Label>
              <Input
                id="bsgsStartRange"
                value={startRange}
                onChange={(e) => setStartRange(e.target.value)}
                className="font-mono text-sm"
                placeholder="Start of search range"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="bsgsEndRange">End Range (hex)</Label>
              <Input
                id="bsgsEndRange"
                value={endRange}
                onChange={(e) => setEndRange(e.target.value)}
                className="font-mono text-sm"
                placeholder="End of search range"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="babySteps">Baby Steps (table size)</Label>
            <Input
              id="babySteps"
              type="number"
              value={babySteps}
              onChange={(e) => setBabySteps(parseInt(e.target.value))}
              min="1000"
              max="10000000"
              placeholder="Number of baby steps to precompute"
            />
            <div className="text-xs text-muted-foreground">
              Higher values use more memory but may find solutions faster. Recommended: 100,000 - 1,000,000
            </div>
          </div>

          <Button 
            onClick={handleRunBsgs}
            disabled={!targetPublicKey || !startRange || !endRange || bsgsMutation.isPending}
            className="w-full"
          >
            {bsgsMutation.isPending ? "Running BSGS..." : "Run BSGS Algorithm"}
          </Button>
        </CardContent>
      </Card>

      {/* BSGS Results */}
      {bsgsMutation.data && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5" />
              BSGS Results
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm">Time: {(bsgsMutation.data as any).executionTime}ms</span>
              </div>
              <div className="flex items-center gap-2">
                <Target className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm">Iterations: {(bsgsMutation.data as any).iterations}</span>
              </div>
              <div className="flex items-center gap-2">
                <Zap className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm">Baby Steps: {(bsgsMutation.data as any).babySteps}</span>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant={(bsgsMutation.data as any).found ? "default" : "secondary"}>
                  {(bsgsMutation.data as any).found ? "FOUND" : "NOT FOUND"}
                </Badge>
              </div>
            </div>

            {(bsgsMutation.data as any).found && (
              <Alert className="border-green-200 bg-green-50 dark:border-green-800 dark:bg-green-950">
                <Target className="h-4 w-4" />
                <AlertDescription>
                  <div className="space-y-3">
                    <div className="font-medium">🎯 Private Key Found via BSGS!</div>
                    
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <Label className="text-xs">Private Key</Label>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => copyToClipboard((bsgsMutation.data as any).privateKey)}
                        >
                          <Copy className="h-3 w-3" />
                        </Button>
                      </div>
                      <div className="font-mono text-sm bg-background p-2 rounded border break-all">
                        {(bsgsMutation.data as any).privateKey}
                      </div>
                    </div>
                    
                    <div className="text-xs text-muted-foreground">
                      Found in {(bsgsMutation.data as any).iterations} iterations using {(bsgsMutation.data as any).babySteps} baby steps
                    </div>
                  </div>
                </AlertDescription>
              </Alert>
            )}

            {!(bsgsMutation.data as any).found && (
              <Alert>
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>
                  <div className="space-y-2">
                    <div className="font-medium">Private Key Not Found</div>
                    <div className="text-sm">
                      The BSGS algorithm completed {(bsgsMutation.data as any).iterations} iterations without finding the target private key.
                      Consider:
                    </div>
                    <ul className="text-sm list-disc list-inside space-y-1 ml-4">
                      <li>Increasing the baby steps for better coverage</li>
                      <li>Expanding the search range</li>
                      <li>Verifying the target public key is correct</li>
                    </ul>
                  </div>
                </AlertDescription>
              </Alert>
            )}

            <div className="text-xs text-muted-foreground space-y-1 p-3 bg-muted/50 rounded">
              <div><strong>Algorithm Details:</strong></div>
              <div>Baby Steps: Precomputed {(bsgsMutation.data as any).babySteps} points</div>
              <div>Giant Steps: Searched through range efficiently</div>
              <div>Memory Usage: O(√n) where n = range size</div>
              <div>Time Complexity: O(√n) for discrete logarithm</div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}