// Utility functions for cryptographic operations
export function isValidHex(hex: string): boolean {
  return /^[0-9a-fA-F]*$/.test(hex);
}

export function formatHex(hex: string): string {
  return hex.replace(/^0x/, "").toLowerCase();
}

export function addHexPrefix(hex: string): string {
  return hex.startsWith("0x") ? hex : `0x${hex}`;
}

export function validatePublicKey(key: string): { isValid: boolean; format?: string; error?: string } {
  const cleanKey = formatHex(key);
  
  if (!isValidHex(cleanKey)) {
    return { isValid: false, error: "Invalid hex format" };
  }

  if (cleanKey.length === 66) {
    const prefix = cleanKey.slice(0, 2);
    if (prefix === "02" || prefix === "03") {
      return { isValid: true, format: "compressed" };
    }
  } else if (cleanKey.length === 130) {
    const prefix = cleanKey.slice(0, 2);
    if (prefix === "04") {
      return { isValid: true, format: "uncompressed" };
    }
  }

  return { isValid: false, error: "Invalid public key length or format" };
}

export function validateSignatureComponent(component: string): boolean {
  const clean = formatHex(component);
  return isValidHex(clean) && clean.length === 64;
}

export function validateMessageHash(hash: string): boolean {
  const clean = formatHex(hash);
  return isValidHex(clean) && clean.length === 64;
}

export function truncateHex(hex: string, maxLength: number = 16): string {
  if (hex.length <= maxLength) return hex;
  return `${hex.slice(0, maxLength / 2)}...${hex.slice(-maxLength / 2)}`;
}

export function copyToClipboard(text: string): Promise<void> {
  return navigator.clipboard.writeText(text);
}

// Secp256k1 curve constants
export const CURVE_CONSTANTS = {
  FIELD_SIZE: "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEFFFFFC2F",
  ORDER: "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141",
  GENERATOR_X: "79BE667EF9DCBBAC55A06295CE870B07029BFCDB2DCE28D959F2815B16F81798",
  GENERATOR_Y: "483ADA7726A3C4655DA4FBFC0E1108A8FD17B448A68554199C47D08FFB10D4B8",
};
