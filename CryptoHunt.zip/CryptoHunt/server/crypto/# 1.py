# 1. your known values
delta_k = int("fffffffffffffffffffffffffffffffebaaedce6af487e246f4eac90b714b3bd", 16)
z1      = int("<hex-of-z1>", 16)
z2      = int("<hex-of-z2>", 16)

# 2. numerator & denominator
num = (delta_k * s1 * s2 + z2 * s1 - z1 * s2) % n
den = (r1 * s2 - r2 * s1) % n
if den == 0:
    raise ValueError("Denominator zero mod n")

# 3. modular inverse & key recovery
inv_den = pow(den, -1, n)
x       = (num * inv_den) % n

print(f"Recovered private key (hex): 0x{x:064x}")
