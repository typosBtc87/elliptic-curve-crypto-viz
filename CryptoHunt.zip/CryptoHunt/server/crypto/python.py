from cryptography.hazmat.primitives.asymmetric import utils

sig1_der = bytes.fromhex("3045…")   # full DER hex of signature #1
sig2_der = bytes.fromhex("3046…")   # full DER hex of signature #2

r1_check, s1 = utils.decode_dss_signature(sig1_der)
r2_check, s2 = utils.decode_dss_signature(sig2_der)

assert r1_check == r1 and r2_check == r2
print(f"s1 = 0x{s1:064x}")
print(f"s2 = 0x{s2:064x}")
