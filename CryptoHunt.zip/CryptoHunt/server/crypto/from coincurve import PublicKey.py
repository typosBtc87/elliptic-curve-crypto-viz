from coincurve import PublicKey
from hashlib import sha256

# compressed R (as hex string)
R1_c_hex = "02de97092bfb7c02148a827b4f8b62db1e189a739c77815799df5e6fb35ae88a1f"
R1_c = bytes.fromhex(R1_c_hex)

# decompress to get x
R1_point = PublicKey(R1_c).format(compressed=False)   # uncompressed format
x_bytes  = R1_point[1:33]                             # bytes 1–32 are x
r1       = int.from_bytes(x_bytes, 'big')

print(f"r1 = 0x{r1:064x}")

