# secp256k1 group order
n       = 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141

# your pre‐computed k₁−k₂  (hex from your notes)
delta_k = int("fffffffffffffffffffffffffffffffebaaedce6af487e246f4eac90b714b3bd", 16)

# now your other signature pieces (example placeholders)
s1      = int("<hex-of-s1>", 16)
s2      = int("<hex-of-s2>", 16)
z1      = int("<hex-of-z1>", 16)
z2      = int("<hex-of-z2>", 16)
r1      = int("<hex-of-r1>", 16)
r2      = int("<hex-of-r2>", 16)

# build the numerator
num = (delta_k * s1 * s2 + z2 * s1 - z1 * s2) % n

# denominator and inverse
den    = (r1 * s2 - r2 * s1) % n
inv_den = pow(den, -1, n)     # Python 3.8+
# inv_den = modinv(den, n)    # if you need your own

# recover the private key
x = (num * inv_den) % n
print(f"private key = 0x{x:064x}")

# all values are integers mod n
num   = (delta_k * s1 * s2 + z2 * s1 - z1 * s2) % n
den   = (r1 * s2 - r2 * s1) % n
x     = num * pow(den, -1, n) % n    # modular inverse via Python 3.8+
