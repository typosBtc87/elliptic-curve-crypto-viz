#!/usr/bin/env python3

from bitcoin import SelectParams
from bitcoin.core import x, CTransaction
from bitcoin.core.script import CScript, SIGHASH_ALL
from bitcoin.core.scripteval import SignatureHash
from bitcoin.core.key import CPubKey

SelectParams('mainnet')

raw_tx = "010000000131290abc3d398848b0028c7e7c26aee1850f0d67eead7d0b0383e44753fc8a48020000006441f3e46f2229b608f8d2ca3b3bda1826c5803a59b2468ba67b8368c014298d8f50c06cbc65f07deb46c63e7afa895752684338b983dcec1f671c25a9dbfba925f5412103bc6d83015634b8071045ef9946cb8c11177d4a7f6f5d98c0d463e2e7a05149e9feffffff015b5c0200000000001976a9143c1603b5eb5f8f732c0943ec791a2221d779debf88ac7dbe0d00"


tx = CTransaction.deserialize(x(raw_tx))

script_pubkey = CScript(x("76a9143c1603b5eb5f8f732c0943ec791a2221d779debf88ac"))

sighash = SignatureHash(script_pubkey, tx, 0, SIGHASH_ALL)

der_sig = x(
  "304402203bae577bd237d77d666f76401b91f4de49e6268d95734aab2d0d5dfac9e7d8c6"
  "02200ea7b7e38dc2719de128bffa5fa166210785cd6a1160324e3bcf2592279cca68"
)
pubkey = CPubKey(x("02f40653bd399bab98f4f465b2d4ad8d0d16c08b4eb3df644140eb33f75ca4df60"))

valid = pubkey.verify(der_sig, sighash, hasher=None)
print("Signature valid?", valid)