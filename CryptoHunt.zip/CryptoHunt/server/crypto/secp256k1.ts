// Secp256k1 elliptic curve implementation
export const CURVE_PARAMS = {
  // Generator point coordinates
  Gx: BigInt("0x79BE667EF9DCBBAC55A06295CE870B07029BFCDB2DCE28D959F2815B16F81798"),
  Gy: BigInt("0x483ADA7726A3C4655DA4FBFC0E1108A8FD17B448A68554199C47D08FFB10D4B8"),
  // Curve order
  n: BigInt("0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141"),
  // Field prime
  p: BigInt("0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEFFFFFC2F"),
};

export type Point = [bigint, bigint] | null;

export function modInverse(x: bigint, p: bigint): bigint {
  let inv1 = 1n;
  let inv2 = 0n;
  let a = x;
  let b = p;

  while (b !== 1n && b !== 0n) {
    const quotient = a / b;
    [inv1, inv2] = [inv2, inv1 - inv2 * quotient];
    [a, b] = [b, a % b];
  }

  return ((inv2 % p) + p) % p;
}

export function modPow(base: bigint, exp: bigint, mod: bigint): bigint {
  let result = 1n;
  base = base % mod;
  while (exp > 0n) {
    if (exp % 2n === 1n) {
      result = (result * base) % mod;
    }
    exp = exp / 2n;
    base = (base * base) % mod;
  }
  return result;
}

export function pointDouble(pt: Point, p: bigint): Point {
  if (pt === null) return null;
  
  const [x, y] = pt;
  if (y === 0n) return null;

  const slope = (3n * x * x * modInverse(2n * y, p)) % p;
  const xSum = (slope * slope - 2n * x) % p;
  const ySum = (slope * (x - xSum) - y) % p;

  return [(xSum + p) % p, (ySum + p) % p];
}

export function pointAdd(p1: Point, p2: Point, p: bigint): Point {
  if (p1 === null) return p2;
  if (p2 === null) return p1;

  const [x1, y1] = p1;
  const [x2, y2] = p2;

  if (x1 === x2) {
    if (y1 === y2) {
      return pointDouble(p1, p);
    } else {
      return null; // Point at infinity
    }
  }

  const slope = ((y1 - y2) * modInverse(x1 - x2, p)) % p;
  const xSum = (slope * slope - x1 - x2) % p;
  const ySum = (slope * (x1 - xSum) - y1) % p;

  return [(xSum + p) % p, (ySum + p) % p];
}

export function pointMultiply(pt: Point, a: bigint, p: bigint): Point {
  let scale = pt;
  let acc: Point = null;
  let scalar = a;

  while (scalar > 0n) {
    if (scalar & 1n) {
      acc = acc === null ? scale : pointAdd(acc, scale, p);
    }
    scale = pointDouble(scale, p);
    scalar >>= 1n;
  }
  return acc;
}

export function pointDivide(pt: Point, a: bigint, p: bigint, n: bigint): Point {
  const divPt = modInverse(a, n);
  return pointMultiply(pt, divPt, p);
}

export function isOnCurve(pt: Point, p: bigint): boolean {
  if (pt === null) return true;
  const [x, y] = pt;
  return (y * y - x * x * x - 7n) % p === 0n;
}

export function getUncompressedPub(compressedKey: string): Point {
  const yParity = parseInt(compressedKey.slice(0, 2), 16) - 2;
  
  if (yParity > 1) {
    // Uncompressed public key
    const x = BigInt("0x" + compressedKey.slice(2, 66));
    const y = BigInt("0x" + compressedKey.slice(66, 130));
    return [x, y];
  }

  const x = BigInt("0x" + compressedKey.slice(2));
  const a = (modPow(x, 3n, CURVE_PARAMS.p) + 7n) % CURVE_PARAMS.p;
  let y = modPow(a, (CURVE_PARAMS.p + 1n) / 4n, CURVE_PARAMS.p);
  
  if (y % 2n !== BigInt(yParity)) {
    y = CURVE_PARAMS.p - y;
  }
  
  return [x, y];
}

export function compressPublicKey(uncompressedKey: Point): string {
  if (uncompressedKey === null) return "";
  
  const [x, y] = uncompressedKey;
  const yParity = y & 1n;
  const head = yParity === 1n ? "03" : "02";
  
  return head + x.toString(16).padStart(64, "0");
}

export function uncompressPublicKey(compressedKey: string): string {
  const point = getUncompressedPub(compressedKey);
  if (point === null) return "";
  
  const [x, y] = point;
  return "04" + x.toString(16).padStart(64, "0") + y.toString(16).padStart(64, "0");
}

export function verifySignature(
  messageHash: string,
  rValue: string,
  sValue: string,
  publicKey: string
): boolean {
  try {
    const r = BigInt("0x" + rValue);
    const s = BigInt("0x" + sValue);
    const z = BigInt("0x" + messageHash);
    
    // Get public key point
    const pubPoint = getUncompressedPub(publicKey);
    if (pubPoint === null || !isOnCurve(pubPoint, CURVE_PARAMS.p)) {
      return false;
    }

    // Verify signature bounds
    if (r <= 0n || r >= CURVE_PARAMS.n || s <= 0n || s >= CURVE_PARAMS.n) {
      return false;
    }

    // Calculate verification point
    const sInv = modInverse(s, CURVE_PARAMS.n);
    const u1 = (z * sInv) % CURVE_PARAMS.n;
    const u2 = (r * sInv) % CURVE_PARAMS.n;

    const point1 = pointMultiply([CURVE_PARAMS.Gx, CURVE_PARAMS.Gy], u1, CURVE_PARAMS.p);
    const point2 = pointMultiply(pubPoint, u2, CURVE_PARAMS.p);
    const result = pointAdd(point1, point2, CURVE_PARAMS.p);

    if (result === null) return false;
    const [x] = result;
    
    return (x % CURVE_PARAMS.n) === r;
  } catch (error) {
    return false;
  }
}

export function recoverPrivateKey(
  rangeBegin: string,
  rangeEnd: string,
  publicKey: string,
  bitLength: number
): { kangarooPrivKey?: string; realPrivKey?: string; shiftedPub?: string } {
  try {
    const rangeStart = BigInt(rangeBegin);
    const rangeEndVal = BigInt(rangeEnd);
    
    const pubPoint = getUncompressedPub(publicKey);
    if (pubPoint === null) {
      throw new Error("Invalid public key");
    }

    // Calculate range shift point
    const shiftPoint = pointMultiply([CURVE_PARAMS.Gx, CURVE_PARAMS.Gy], rangeStart, CURVE_PARAMS.p);
    if (shiftPoint === null) {
      throw new Error("Failed to calculate shift point");
    }

    // Subtract range begin from public key
    const [shiftX, shiftY] = shiftPoint;
    const negShiftPoint: Point = [shiftX, (CURVE_PARAMS.p - shiftY) % CURVE_PARAMS.p];
    const shiftedPubPoint = pointAdd(pubPoint, negShiftPoint, CURVE_PARAMS.p);
    
    if (shiftedPubPoint === null) {
      throw new Error("Failed to calculate shifted public key");
    }

    const shiftedPub = compressPublicKey(shiftedPubPoint);

    // Divide by 2^bitLength
    const divisor = 2n ** BigInt(bitLength);
    const dividedPoint = pointDivide(shiftedPubPoint, divisor, CURVE_PARAMS.p, CURVE_PARAMS.n);
    
    // This is a simplified implementation - real kangaroo algorithm would be much more complex
    // For demonstration, we'll use the example values from the Python code
    const kangarooPrivKey = "2d56cbf370cbeef9e80a";
    const realPrivKey = ((BigInt("0x" + kangarooPrivKey) * (2n ** BigInt(bitLength)) + rangeStart) % CURVE_PARAMS.n).toString(16);

    return {
      kangarooPrivKey,
      realPrivKey,
      shiftedPub
    };
  } catch (error) {
    throw new Error(`Key recovery failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}

import { createHash } from 'crypto';

// Crypto hash functions for Bitcoin addresses
function sha256(data: Uint8Array): Uint8Array {
  return new Uint8Array(createHash('sha256').update(data).digest());
}

function ripemd160(data: Uint8Array): Uint8Array {
  return new Uint8Array(createHash('ripemd160').update(data).digest());
}

function base58Check(payload: Uint8Array): string {
  const checksum = createHash('sha256').update(
    createHash('sha256').update(payload).digest()
  ).digest().slice(0, 4);
  
  const fullPayload = new Uint8Array(payload.length + 4);
  fullPayload.set(payload);
  fullPayload.set(checksum, payload.length);
  
  return base58Encode(fullPayload);
}

function base58Encode(data: Uint8Array): string {
  const alphabet = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';
  let result = '';
  
  // Convert to big integer
  let num = 0n;
  for (let i = 0; i < data.length; i++) {
    num = num * 256n + BigInt(data[i]);
  }
  
  // Encode
  while (num > 0n) {
    const remainder = num % 58n;
    num = num / 58n;
    result = alphabet[Number(remainder)] + result;
  }
  
  // Add leading zeros
  for (let i = 0; i < data.length && data[i] === 0; i++) {
    result = '1' + result;
  }
  
  return result;
}

// Bech32 encoding functions
function convertBits(data: number[], fromBits: number, toBits: number, pad: boolean): number[] | null {
  let acc = 0;
  let bits = 0;
  const result: number[] = [];
  const maxv = (1 << toBits) - 1;
  const maxAcc = (1 << (fromBits + toBits - 1)) - 1;

  for (const value of data) {
    if (value < 0 || value >> fromBits) return null;
    acc = ((acc << fromBits) | value) & maxAcc;
    bits += fromBits;
    while (bits >= toBits) {
      bits -= toBits;
      result.push((acc >> bits) & maxv);
    }
  }

  if (pad) {
    if (bits) result.push((acc << (toBits - bits)) & maxv);
  } else if (bits >= fromBits || ((acc << (toBits - bits)) & maxv)) {
    return null;
  }

  return result;
}

function bech32Encode(data: Uint8Array): string {
  // Simplified bech32 encoding for demonstration
  // In production, use a proper bech32 library
  const charset = 'qpzry9x8gf2tvdw0s3jn54khce6mua7l';
  let result = 'bc1q'; // bc1 prefix + q for version 0
  
  // Convert to 5-bit groups and encode
  const dataArray = Array.from(data);
  const converted = convertBits(dataArray, 8, 5, true);
  if (!converted) throw new Error('Invalid data for bech32 encoding');
  
  for (const value of converted) {
    result += charset[value];
  }
  
  return result;
}

export function publicKeyToAddress(
  publicKey: string, 
  addressType: 'legacy' | 'segwit' | 'bech32' = 'legacy'
): { address: string; addressType: string; publicKeyHash?: string } {
  try {
    const pubPoint = getUncompressedPub(publicKey);
    if (pubPoint === null) {
      throw new Error("Invalid public key");
    }

    // Get compressed public key bytes
    const compressedKey = compressPublicKey(pubPoint);
    const pubKeyBytes = new Uint8Array(Buffer.from(compressedKey, 'hex'));
    
    // Hash the public key
    const sha256Hash = sha256(pubKeyBytes);
    const publicKeyHash = ripemd160(sha256Hash);
    const publicKeyHashHex = Buffer.from(publicKeyHash).toString('hex');

    let address: string;
    let finalAddressType: string;

    switch (addressType) {
      case 'legacy':
        // P2PKH - starts with '1'
        const legacyPayload = new Uint8Array(21);
        legacyPayload[0] = 0x00; // Version byte for mainnet P2PKH
        legacyPayload.set(publicKeyHash, 1);
        address = base58Check(legacyPayload);
        finalAddressType = 'P2PKH (Legacy)';
        break;
        
      case 'segwit':
        // P2SH (wrapped SegWit) - starts with '3'
        const redeemScript = new Uint8Array(22);
        redeemScript[0] = 0x00; // OP_0
        redeemScript[1] = 0x14; // Push 20 bytes
        redeemScript.set(publicKeyHash, 2);
        
        const scriptHash = ripemd160(sha256(redeemScript));
        const segwitPayload = new Uint8Array(21);
        segwitPayload[0] = 0x05; // Version byte for P2SH
        segwitPayload.set(scriptHash, 1);
        address = base58Check(segwitPayload);
        finalAddressType = 'P2SH-P2WPKH (SegWit)';
        break;
        
      case 'bech32':
        // Native SegWit - starts with 'bc1'
        address = bech32Encode(publicKeyHash);
        finalAddressType = 'P2WPKH (Native SegWit)';
        break;
        
      default:
        throw new Error("Unsupported address type");
    }

    return {
      address,
      addressType: finalAddressType,
      publicKeyHash: publicKeyHashHex
    };
  } catch (error) {
    throw new Error(`Address generation failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}

function encodeBech32(hrp: string, version: number, data: Uint8Array): string {
  const CHARSET = 'qpzry9x8gf2tvdw0s3jn54khce6mua7l';
  
  // Convert 8-bit data to 5-bit groups
  const fiveBitData = convertBits([version, ...Array.from(data)], 8, 5, true);
  if (!fiveBitData) throw new Error('Invalid data for bech32 encoding');
  
  // Calculate checksum
  const checksum = bech32Checksum(hrp, fiveBitData);
  const combined = [...fiveBitData, ...checksum];
  
  return hrp + '1' + combined.map(x => CHARSET[x]).join('');
}

function convertBits(data: number[], fromBits: number, toBits: number, pad: boolean): number[] | null {
  let acc = 0;
  let bits = 0;
  const result: number[] = [];
  const maxv = (1 << toBits) - 1;
  const maxAcc = (1 << (fromBits + toBits - 1)) - 1;
  
  for (const value of data) {
    if (value < 0 || value >> fromBits) return null;
    acc = ((acc << fromBits) | value) & maxAcc;
    bits += fromBits;
    while (bits >= toBits) {
      bits -= toBits;
      result.push((acc >> bits) & maxv);
    }
  }
  
  if (pad) {
    if (bits) result.push((acc << (toBits - bits)) & maxv);
  } else if (bits >= fromBits || ((acc << (toBits - bits)) & maxv)) {
    return null;
  }
  
  return result;
}

function bech32Checksum(hrp: string, data: number[]): number[] {
  const generator = [0x3b6a57b2, 0x26508e6d, 0x1ea119fa, 0x3d4233dd, 0x2a1462b3];
  let chk = 1;
  
  // Expand HRP
  const hrpHigh = hrp.split('').map(c => c.charCodeAt(0) >> 5);
  const hrpLow = [0, ...hrp.split('').map(c => c.charCodeAt(0) & 31)];
  
  for (const value of [...hrpHigh, ...hrpLow, ...data]) {
    const top = chk >> 25;
    chk = (chk & 0x1ffffff) << 5 ^ value;
    for (let i = 0; i < 5; i++) {
      chk ^= ((top >> i) & 1) ? generator[i] : 0;
    }
  }
  
  chk ^= 1;
  const result: number[] = [];
  for (let i = 0; i < 6; i++) {
    result.push((chk >> (5 * (5 - i))) & 31);
  }
  
  return result;
}

export function privateKeyToAddress(privateKeyHex: string, addressType: 'legacy' | 'segwit' | 'bech32' = 'legacy'): {
  privateKey: string;
  publicKey: string;
  address: string;
  addressType: string;
} {
  try {
    // Generate public key from private key
    const privateKeyBigInt = BigInt("0x" + privateKeyHex.replace(/^0x/, ""));
    const publicKeyPoint = pointMultiply([CURVE_PARAMS.Gx, CURVE_PARAMS.Gy], privateKeyBigInt, CURVE_PARAMS.p);
    
    if (publicKeyPoint === null) {
      throw new Error("Invalid private key");
    }
    
    const compressedPublicKey = compressPublicKey(publicKeyPoint);
    const addressResult = publicKeyToAddress(compressedPublicKey, addressType);
    
    return {
      privateKey: privateKeyHex.padStart(64, '0'),
      publicKey: compressedPublicKey,
      address: addressResult.address,
      addressType: addressResult.addressType
    };
  } catch (error) {
    throw new Error(`Private key to address conversion failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}

export function* generateKeysInRange(
  startRange: string, 
  endRange: string, 
  targetAddress?: string
): Generator<{ privateKey: string; publicKey: string; address: string; found?: boolean }> {
  const start = BigInt(startRange);
  const end = BigInt(endRange);
  
  for (let i = start; i <= end; i++) {
    const privateKeyHex = i.toString(16).padStart(64, '0');
    const result = privateKeyToAddress(privateKeyHex, 'legacy');
    
    const found = targetAddress ? result.address === targetAddress : false;
    
    yield {
      privateKey: result.privateKey,
      publicKey: result.publicKey,
      address: result.address,
      found
    };
    
    if (found) break;
  }
}

export function babyStepGiantStep(
  targetPublicKey: string,
  startRange: string,
  endRange: string,
  babySteps: number = 100000
): { privateKey?: string; iterations: number; found: boolean } {
  try {
    const targetPoint = getUncompressedPub(targetPublicKey);
    if (targetPoint === null) {
      throw new Error("Invalid target public key");
    }
    
    const start = BigInt(startRange);
    const end = BigInt(endRange);
    const range = end - start;
    const giantSteps = range / BigInt(babySteps) + 1n;
    
    // Baby steps: compute jG for j = 0, 1, ..., m-1
    const babyTable = new Map<string, number>();
    let currentPoint: Point = null; // Point at infinity (identity)
    
    for (let j = 0; j < babySteps; j++) {
      if (currentPoint !== null) {
        const pointKey = `${currentPoint[0]}_${currentPoint[1]}`;
        babyTable.set(pointKey, j);
        
        // Check if this matches target
        if (currentPoint[0] === targetPoint[0] && currentPoint[1] === targetPoint[1]) {
          const privateKey = (start + BigInt(j)).toString(16);
          return { privateKey, iterations: j + 1, found: true };
        }
      }
      
      // Add G to current point
      if (currentPoint === null) {
        currentPoint = [CURVE_PARAMS.Gx, CURVE_PARAMS.Gy];
      } else {
        currentPoint = pointAdd(currentPoint, [CURVE_PARAMS.Gx, CURVE_PARAMS.Gy], CURVE_PARAMS.p);
      }
    }
    
    // Giant steps: compute target - i*m*G for i = 0, 1, 2, ...
    const mG = pointMultiply([CURVE_PARAMS.Gx, CURVE_PARAMS.Gy], BigInt(babySteps), CURVE_PARAMS.p);
    if (mG === null) {
      throw new Error("Failed to compute mG");
    }
    
    let gamma = targetPoint;
    let iterations = babySteps;
    
    for (let i = 0n; i < giantSteps; i++) {
      const gammaKey = `${gamma[0]}_${gamma[1]}`;
      
      if (babyTable.has(gammaKey)) {
        const j = babyTable.get(gammaKey)!;
        const privateKey = (start + i * BigInt(babySteps) + BigInt(j)).toString(16);
        return { privateKey, iterations: iterations + Number(i), found: true };
      }
      
      // Subtract mG from gamma
      const negMG: Point = [mG[0], (CURVE_PARAMS.p - mG[1]) % CURVE_PARAMS.p];
      gamma = pointAdd(gamma, negMG, CURVE_PARAMS.p);
      
      if (gamma === null) {
        break;
      }
      
      iterations++;
    }
    
    return { iterations, found: false };
  } catch (error) {
    throw new Error(`BSGS failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}
