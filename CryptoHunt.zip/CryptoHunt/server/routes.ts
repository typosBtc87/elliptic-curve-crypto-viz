import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import {
  publicKeySchema,
  signatureVerificationSchema,
  keyRecoverySchema,
  pointOperationSchema,
  addressGenerationSchema,
  puzzleSolverSchema,
  bsgsSchema,
} from "@shared/schema";
import {
  getUncompressedPub,
  compressPublicKey,
  uncompressPublicKey,
  isOnCurve,
  verifySignature,
  recoverPrivateKey,
  pointAdd,
  pointDouble,
  pointMultiply,
  pointDivide,
  publicKeyToAddress,
  privateKeyToAddress,
  generateKeysInRange,
  babyStepGiantStep,
  CURVE_PARAMS,
} from "./crypto/secp256k1";

export async function registerRoutes(app: Express): Promise<Server> {
  // Public key operations
  app.post("/api/crypto/public-key", async (req, res) => {
    try {
      const { publicKey } = publicKeySchema.parse(req.body);

      // Remove any whitespace and validate format
      const cleanKey = publicKey.replace(/\s/g, "");
      
      if (!/^[0-9a-fA-F]+$/.test(cleanKey)) {
        return res.status(400).json({ error: "Invalid hex format" });
      }

      let compressed: string;
      let uncompressed: string;
      let coordinates: { x: string; y: string };
      let isValid = false;

      try {
        const point = getUncompressedPub(cleanKey);
        if (point) {
          isValid = isOnCurve(point, CURVE_PARAMS.p);
          const [x, y] = point;
          coordinates = {
            x: x.toString(16).padStart(64, "0"),
            y: y.toString(16).padStart(64, "0"),
          };
          compressed = compressPublicKey(point);
          uncompressed = uncompressPublicKey(cleanKey);
        } else {
          throw new Error("Invalid point");
        }
      } catch (error) {
        return res.status(400).json({ error: "Invalid public key format" });
      }

      const result = {
        compressed,
        uncompressed,
        coordinates,
        isValid,
        format: cleanKey.length === 66 ? "compressed" : "uncompressed",
        length: cleanKey.length / 2,
      };

      // Store operation
      await storage.createCryptoOperation({
        operationType: "public_key_conversion",
        inputData: { publicKey: cleanKey },
        result,
        status: "completed",
      });

      res.json(result);
    } catch (error) {
      res.status(400).json({ 
        error: error instanceof Error ? error.message : "Invalid input" 
      });
    }
  });

  // Signature verification
  app.post("/api/crypto/verify-signature", async (req, res) => {
    try {
      const { messageHash, rValue, sValue, publicKey } = signatureVerificationSchema.parse(req.body);

      // Clean inputs
      const cleanHash = messageHash.replace(/\s/g, "").replace(/^0x/, "");
      const cleanR = rValue.replace(/\s/g, "").replace(/^0x/, "");
      const cleanS = sValue.replace(/\s/g, "").replace(/^0x/, "");
      const cleanPubKey = publicKey.replace(/\s/g, "");

      // Validate inputs
      const validations = {
        messageHashValid: /^[0-9a-fA-F]{64}$/.test(cleanHash),
        signatureFormatValid: /^[0-9a-fA-F]{64}$/.test(cleanR) && /^[0-9a-fA-F]{64}$/.test(cleanS),
        publicKeyValid: false,
        ecdsaVerification: false,
      };

      try {
        const pubPoint = getUncompressedPub(cleanPubKey);
        validations.publicKeyValid = pubPoint !== null && isOnCurve(pubPoint, CURVE_PARAMS.p);
      } catch {
        validations.publicKeyValid = false;
      }

      if (validations.messageHashValid && validations.signatureFormatValid && validations.publicKeyValid) {
        validations.ecdsaVerification = verifySignature(cleanHash, cleanR, cleanS, cleanPubKey);
      }

      const result = {
        isValid: validations.ecdsaVerification,
        validations,
      };

      // Store operation
      await storage.createCryptoOperation({
        operationType: "signature_verification",
        inputData: { messageHash: cleanHash, rValue: cleanR, sValue: cleanS, publicKey: cleanPubKey },
        result,
        status: "completed",
      });

      res.json(result);
    } catch (error) {
      res.status(400).json({ 
        error: error instanceof Error ? error.message : "Invalid input" 
      });
    }
  });

  // Private key recovery
  app.post("/api/crypto/recover-key", async (req, res) => {
    try {
      const { rangeBegin, rangeEnd, publicKey, bitLength } = keyRecoverySchema.parse(req.body);

      const cleanRangeBegin = rangeBegin.replace(/\s/g, "");
      const cleanRangeEnd = rangeEnd.replace(/\s/g, "");
      const cleanPubKey = publicKey.replace(/\s/g, "");

      if (!/^0x[0-9a-fA-F]+$/.test(cleanRangeBegin) || !/^0x[0-9a-fA-F]+$/.test(cleanRangeEnd)) {
        return res.status(400).json({ error: "Range values must be in hex format with 0x prefix" });
      }

      const recovery = recoverPrivateKey(cleanRangeBegin, cleanRangeEnd, cleanPubKey, bitLength);

      const result = {
        ...recovery,
        progress: 100,
        status: "completed",
      };

      // Store operation
      await storage.createCryptoOperation({
        operationType: "key_recovery",
        inputData: { rangeBegin: cleanRangeBegin, rangeEnd: cleanRangeEnd, publicKey: cleanPubKey, bitLength },
        result,
        status: "completed",
      });

      res.json(result);
    } catch (error) {
      res.status(400).json({ 
        error: error instanceof Error ? error.message : "Key recovery failed" 
      });
    }
  });

  // Point operations
  app.post("/api/crypto/point-operation", async (req, res) => {
    try {
      const { operation, point1X, point1Y, point2X, point2Y, scalar } = pointOperationSchema.parse(req.body);

      let result: any = {};

      try {
        switch (operation) {
          case "add": {
            if (!point1X || !point1Y || !point2X || !point2Y) {
              throw new Error("Point addition requires both points");
            }
            const p1: [bigint, bigint] = [BigInt("0x" + point1X), BigInt("0x" + point1Y)];
            const p2: [bigint, bigint] = [BigInt("0x" + point2X), BigInt("0x" + point2Y)];
            const resultPoint = pointAdd(p1, p2, CURVE_PARAMS.p);
            result = resultPoint ? {
              x: resultPoint[0].toString(16),
              y: resultPoint[1].toString(16),
            } : { error: "Point at infinity" };
            break;
          }
          case "double": {
            if (!point1X || !point1Y) {
              throw new Error("Point doubling requires one point");
            }
            const p1: [bigint, bigint] = [BigInt("0x" + point1X), BigInt("0x" + point1Y)];
            const resultPoint = pointDouble(p1, CURVE_PARAMS.p);
            result = resultPoint ? {
              x: resultPoint[0].toString(16),
              y: resultPoint[1].toString(16),
            } : { error: "Point at infinity" };
            break;
          }
          case "multiply": {
            if (!point1X || !point1Y || !scalar) {
              throw new Error("Scalar multiplication requires point and scalar");
            }
            const p1: [bigint, bigint] = [BigInt("0x" + point1X), BigInt("0x" + point1Y)];
            const k = BigInt(scalar.startsWith("0x") ? scalar : "0x" + scalar);
            const resultPoint = pointMultiply(p1, k, CURVE_PARAMS.p);
            result = resultPoint ? {
              x: resultPoint[0].toString(16),
              y: resultPoint[1].toString(16),
            } : { error: "Point at infinity" };
            break;
          }
          case "divide": {
            if (!point1X || !point1Y || !scalar) {
              throw new Error("Point division requires point and scalar");
            }
            const p1: [bigint, bigint] = [BigInt("0x" + point1X), BigInt("0x" + point1Y)];
            const k = BigInt(scalar.startsWith("0x") ? scalar : "0x" + scalar);
            const resultPoint = pointDivide(p1, k, CURVE_PARAMS.p, CURVE_PARAMS.n);
            result = resultPoint ? {
              x: resultPoint[0].toString(16),
              y: resultPoint[1].toString(16),
            } : { error: "Point at infinity" };
            break;
          }
          case "validate": {
            if (!point1X || !point1Y) {
              throw new Error("Point validation requires coordinates");
            }
            const p1: [bigint, bigint] = [BigInt("0x" + point1X), BigInt("0x" + point1Y)];
            result = { isValid: isOnCurve(p1, CURVE_PARAMS.p) };
            break;
          }
          default:
            throw new Error("Unsupported operation");
        }
      } catch (opError) {
        result = { error: opError instanceof Error ? opError.message : "Operation failed" };
      }

      // Store operation
      await storage.createCryptoOperation({
        operationType: "point_operation",
        inputData: { operation, point1X, point1Y, point2X, point2Y, scalar },
        result,
        status: "completed",
      });

      res.json(result);
    } catch (error) {
      res.status(400).json({ 
        error: error instanceof Error ? error.message : "Invalid input" 
      });
    }
  });

  // Bitcoin address generation endpoint
  app.post("/api/crypto/generate-address", async (req, res) => {
    try {
      const { publicKey, addressType } = addressGenerationSchema.parse(req.body);
      
      const result = publicKeyToAddress(publicKey, addressType);
      
      res.json(result);
    } catch (error) {
      console.error("Address generation error:", error);
      res.status(400).json({ error: error instanceof Error ? error.message : "Address generation failed" });
    }
  });

  // Private key to address conversion endpoint
  app.post("/api/crypto/private-to-address", async (req, res) => {
    try {
      const { privateKey, addressType = "legacy" } = req.body;
      
      if (!privateKey) {
        return res.status(400).json({ error: "Private key is required" });
      }
      
      const result = privateKeyToAddress(privateKey, addressType);
      
      res.json(result);
    } catch (error) {
      console.error("Private to address conversion error:", error);
      res.status(400).json({ error: error instanceof Error ? error.message : "Conversion failed" });
    }
  });

  // Bitcoin puzzle solver endpoint (range search)
  app.post("/api/crypto/solve-puzzle", async (req, res) => {
    try {
      const { startRange, endRange, targetAddress, searchMode, bitLength, maxIterations = 10000 } = puzzleSolverSchema.parse(req.body);
      
      let found = false;
      let foundPrivateKey: string | undefined;
      let foundAddress: string | undefined;
      let iterations = 0;
      let progress = 0;
      
      const start = BigInt(startRange);
      const end = BigInt(endRange);
      const range = end - start;
      
      // Use generator for memory efficiency
      const keyGenerator = generateKeysInRange(startRange, endRange, targetAddress);
      
      for (const keyData of keyGenerator) {
        iterations++;
        progress = Number((BigInt(iterations) * 100n) / range);
        
        if (keyData.found) {
          found = true;
          foundPrivateKey = keyData.privateKey;
          foundAddress = keyData.address;
          break;
        }
        
        // Limit iterations to prevent server overload
        if (iterations >= maxIterations) {
          break;
        }
      }
      
      res.json({
        found,
        privateKey: foundPrivateKey,
        address: foundAddress,
        iterations,
        progress: Math.min(progress, 100),
        searchMode,
        bitLength,
        range: {
          start: startRange,
          end: endRange,
          size: range.toString()
        }
      });
    } catch (error) {
      console.error("Puzzle solver error:", error);
      res.status(400).json({ error: error instanceof Error ? error.message : "Puzzle solving failed" });
    }
  });

  // Baby-Step Giant-Step algorithm endpoint
  app.post("/api/crypto/bsgs", async (req, res) => {
    try {
      const { targetPublicKey, startRange, endRange, babySteps } = bsgsSchema.parse(req.body);
      
      const startTime = Date.now();
      const result = babyStepGiantStep(targetPublicKey, startRange, endRange, babySteps);
      const endTime = Date.now();
      
      res.json({
        ...result,
        executionTime: endTime - startTime,
        babySteps,
        range: {
          start: startRange,
          end: endRange
        }
      });
    } catch (error) {
      console.error("BSGS error:", error);
      res.status(400).json({ error: error instanceof Error ? error.message : "BSGS algorithm failed" });
    }
  });

  // Known Bitcoin puzzles database endpoint
  app.get("/api/crypto/puzzles", async (req, res) => {
    try {
      const knownPuzzles = [
        {
          puzzle: 66,
          bits: 66,
          status: "SOLVED",
          reward: "6.6 BTC",
          address: "13zb1hQbWVsc2S7ZTZnP2G4undNNpdh5so",
          range: { start: "20000000000000000", end: "3ffffffffffffffff" },
          privateKey: "349b84b6431a6c4ef1006c0e710903eeabb8825e5eb5ee85ae58726af40f1082",
          solvedDate: "September 2024"
        },
        {
          puzzle: 67,
          bits: 67,
          status: "UNSOLVED",
          reward: "6.7 BTC",
          address: "1BY8GQbnueYofwSuFAT3USAhGjPrkxDdW9",
          range: { start: "40000000000000000", end: "7ffffffffffffffff" },
          privateKey: null,
          solvedDate: null
        },
        {
          puzzle: 68,
          bits: 68,
          status: "UNSOLVED", 
          reward: "6.8 BTC",
          address: "1MVDYgVaSN6iKKEsbzRUAYFrYJadLYZvvZ",
          range: { start: "80000000000000000", end: "ffffffffffffffffff" },
          privateKey: null,
          solvedDate: null
        },
        {
          puzzle: 69,
          bits: 69,
          status: "UNSOLVED",
          reward: "6.9 BTC", 
          address: "19vkiEajfhuZ8bs8Zu2jgmC6oqZbWqhxhG",
          range: { start: "100000000000000000", end: "1ffffffffffffffffff" },
          privateKey: null,
          solvedDate: null
        },
        {
          puzzle: 70,
          bits: 70,
          status: "UNSOLVED",
          reward: "7.0 BTC",
          address: "1PWo3JeB9jrGwfHDNpdGK54CRas7fsVzXU",
          range: { start: "200000000000000000", end: "3ffffffffffffffffff" },
          privateKey: null,
          solvedDate: null
        }
      ];
      
      res.json({
        puzzles: knownPuzzles,
        totalUnsolved: knownPuzzles.filter(p => p.status === "UNSOLVED").length,
        totalReward: knownPuzzles.reduce((sum, p) => sum + parseFloat(p.reward), 0).toFixed(1) + " BTC"
      });
    } catch (error) {
      console.error("Puzzles database error:", error);
      res.status(500).json({ error: "Failed to fetch puzzles data" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
