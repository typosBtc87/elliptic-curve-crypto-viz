import { type CryptoOperation, type InsertCryptoOperation } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getCryptoOperation(id: string): Promise<CryptoOperation | undefined>;
  createCryptoOperation(operation: InsertCryptoOperation): Promise<CryptoOperation>;
  updateCryptoOperation(id: string, updates: Partial<CryptoOperation>): Promise<CryptoOperation | undefined>;
  listCryptoOperations(): Promise<CryptoOperation[]>;
}

export class MemStorage implements IStorage {
  private operations: Map<string, CryptoOperation>;

  constructor() {
    this.operations = new Map();
  }

  async getCryptoOperation(id: string): Promise<CryptoOperation | undefined> {
    return this.operations.get(id);
  }

  async createCryptoOperation(insertOperation: InsertCryptoOperation): Promise<CryptoOperation> {
    const id = randomUUID();
    const operation: CryptoOperation = {
      ...insertOperation,
      id,
      createdAt: new Date(),
    };
    this.operations.set(id, operation);
    return operation;
  }

  async updateCryptoOperation(id: string, updates: Partial<CryptoOperation>): Promise<CryptoOperation | undefined> {
    const existing = this.operations.get(id);
    if (!existing) return undefined;

    const updated = { ...existing, ...updates };
    this.operations.set(id, updated);
    return updated;
  }

  async listCryptoOperations(): Promise<CryptoOperation[]> {
    return Array.from(this.operations.values()).sort(
      (a, b) => (b.createdAt?.getTime() || 0) - (a.createdAt?.getTime() || 0)
    );
  }
}

export const storage = new MemStorage();
