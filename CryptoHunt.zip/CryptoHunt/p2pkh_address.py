from btclib.ec import dsa
from btclib.ec.curve import secp256k1
from btclib.tx.pay_to import pubkey_to_p2pkh_address

priv_key = 0x1A2B3C4D5E6F778899AABBCCDDEEFF00112233445566778899AABBCCDDEEFF00
pub_key = dsa.pub_key(secp256k1, priv_key)

address = pubkey_to_p2pkh_address(pub_key)
print(f"P2PKH Address: {address}")